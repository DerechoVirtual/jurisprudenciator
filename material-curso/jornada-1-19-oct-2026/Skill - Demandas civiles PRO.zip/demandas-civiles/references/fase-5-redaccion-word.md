# FASE 5 — Redacción extensa y entrega Word maquetado

> **Regla cardinal**: la entrega final es siempre `.docx` perfectamente maquetado. Nunca texto plano, nunca Markdown, nunca "te paso el contenido por chat".

## 1. Estructura del escrito (en este orden, sin saltarse ninguna sección)

```
[ENCABEZAMIENTO — centrado, mayúsculas, negrita]
AL TRIBUNAL DE INSTANCIA DE [LOCALIDAD]
SECCIÓN [CIVIL / FAMILIA / MERCANTIL]

[COMPARECENCIA]
D./Dña. [PROCURADOR], Procurador de los Tribunales (Col. nº [X]), en nombre y 
representación de D./Dña. [CLIENTE], según acredito mediante poder que se 
acompaña como Documento nº 1, bajo la dirección letrada de D./Dña. [LETRADO], 
abogado del ICAM nº [X], con despacho profesional en [DIRECCIÓN] y dirección 
electrónica para notificaciones [EMAIL LexNET], ante el Tribunal comparezco y 
como mejor proceda en Derecho, DIGO:

[FÓRMULA PROCESAL]
Que mediante el presente escrito, y siguiendo expresas instrucciones de mi 
mandante, vengo a INTERPONER DEMANDA DE JUICIO [ORDINARIO / VERBAL / MONITORIO] 
frente a [DEMANDADO], con [DNI/CIF] y domicilio en [DIRECCIÓN], en virtud 
de los siguientes:

H E C H O S

PRIMERO.- [Origen de la relación jurídica].
SEGUNDO.- [Cumplimiento del actor].
TERCERO.- [Incumplimiento del demandado].
CUARTO.- [Reclamación extrajudicial / MASC].
QUINTO.- [Cuantificación de la deuda].

A los anteriores hechos resultan de aplicación los siguientes:

F U N D A M E N T O S    D E    D E R E C H O

I.- COMPETENCIA OBJETIVA Y TERRITORIAL.
   [Cita arts. 50-52 LEC + arts. 86 ter LOPJ].

II.- LEGITIMACIÓN ACTIVA Y PASIVA.
   [Cita art. 10 LEC y razón de la legitimación].

III.- PROCEDIMIENTO APLICABLE.
   [Cita arts. 248-250 LEC].

IV.- POSTULACIÓN PROCESAL.
   [Cita arts. 23 y 31 LEC].

V.- CUMPLIMIENTO DEL REQUISITO DE PROCEDIBILIDAD (ART. 5 LO 1/2025).
   [Acreditar el MASC o justificar excepción].

VI.- FONDO DEL ASUNTO.
   [Cita normativa sustantiva + 3-4 STS con subsunción a los hechos].

VII.- COSTAS E INTERESES.
   [Cita arts. 394 LEC, 1108 CC, 576 LEC + STS de costas si procede].

[SUPLICO]
SUPLICO AL TRIBUNAL DE INSTANCIA: que tenga por presentado este escrito y 
los documentos que se acompañan, se sirva admitirlo, dándole el trámite del 
juicio [X], y, previos los trámites legales, dicte sentencia por la que:

PRIMERO.- Estime íntegramente la presente demanda.
SEGUNDO.- Condene a la parte demandada a abonar a mi mandante:
   a) La cantidad de [X] euros.
   b) Los intereses [...]
   c) Las costas procesales.

[OTROSÍES]
OTROSÍ PRIMERO DIGO: Que la cuantía del presente procedimiento se fija 
expresamente en [X] euros, correspondiendo el trámite del juicio [X].
SUPLICO AL TRIBUNAL DE INSTANCIA tenga por hecha la anterior manifestación.

OTROSÍ SEGUNDO DIGO: Que esta parte se valdrá de los siguientes medios de 
prueba: a) documental (Doc. 1 a [N]); b) interrogatorio del legal representante 
de la demandada; [...]
SUPLICO AL TRIBUNAL DE INSTANCIA tenga por anunciada la anterior prueba a los 
efectos del art. 265.1 LEC.

OTROSÍ TERCERO DIGO: Que se designa como dirección electrónica para 
notificaciones [EMAIL LexNET].
SUPLICO AL TRIBUNAL DE INSTANCIA tenga por hecha la anterior designación.

[CIERRE]
Es justicia que se pide en [LOCALIDAD], a [FECHA].

[FIRMA - dos columnas]
Fdo.: [LETRADO]                           Fdo.: [PROCURADOR]
Abogado ICAM nº [X]                        Procurador Col. nº [X]

[DOCUMENTOS]
Se acompañan los siguientes documentos:
   Doc. 1.- Poder general para pleitos.
   Doc. 2.- Contrato de [...]
   Doc. 3.- Factura [...]
   [...]
   Doc. [N].- Burofax MASC con acuse de recibo y certificación de contenido.
```

## 2. Reglas de redacción

### Tono y registro

- Tercera persona y "esta parte" (no "yo", no "nosotros").
- Tiempo verbal: presente histórico para los hechos pasados consolidados.
- Sin coloquialismos, sin adjetivos enfáticos sin justificación factual.
- Verbos rotando (señala, indica, declara, sostiene, razona, concluye, recuerda, advierte, precisa, matiza).

### Numeración

- HECHOS: ordinal escrito (PRIMERO, SEGUNDO, TERCERO…).
- FUNDAMENTOS DE DERECHO: ordinal romano (I, II, III…).
- SUPLICO: peticiones con cardinal escrito (PRIMERO, SEGUNDO…) o letras (a, b, c…).
- OTROSÍES: ordinal escrito (OTROSÍ PRIMERO, OTROSÍ SEGUNDO…).

### Citas

- Artículos: "art. 5 LO 1/2025", "art. 1108 CC", "arts. 50-52 LEC".
- Sentencias: "STS Sala Primera nº [X]/[año], de [día] de [mes] [ECLI:ES:TS:[año]:[número]]".
- Fragmentos textuales entre comillas latinas (« »).

### Negritas estratégicas

- Encabezamiento del tribunal.
- Nombres de las partes (primera mención de cada uno).
- Importes principales.
- Fechas críticas (vencimiento, MASC, prescripción).
- ECLI.
- Verbos rectores del suplico (ESTIME, CONDENE, DECLARE).

## 3. Generación del Word

### Opción preferente: script propio

```bash
python3 scripts/generar_demanda_word.py --json caso.json --output demanda.docx
```

El script aplica directamente:
- Times New Roman 12 pt.
- Interlineado 1,15.
- Márgenes 3/2,5/2,5/2,5 cm.
- Estilos por sección (encabezamiento, hechos, fundamentos, suplico, otrosíes).
- Pie de firma a dos columnas.
- Numeración correlativa de páginas.

Ver el script para el JSON de entrada esperado.

### Opción alternativa: skill `docx`

Si el script no está disponible, invocar la skill `docx` con instrucciones detalladas de formato (Times 12, márgenes, estilos, pie de firma).

### Opción NO permitida: Markdown / texto plano

**Prohibido entregar el escrito en Markdown o texto plano.** Si por cualquier motivo no se puede generar el Word, parar y avisar a Carlos antes de enviar nada.

## 4. Pasada final de estilo Carlos

Antes de entregar, **invocar siempre** la skill `estilo-carlos-escritos-judiciales`:

- Aplica estructura tripartita.
- Inserta contrastes "una cosa es X / otra Y".
- Reordena para que el "por qué" preceda al "qué" en cada FD.
- Cierre estratégico al final de cada bloque.
- Eliminar adjetivos vacíos.

Sin esta pasada el escrito **no se entrega**.

## 5. Verificación ECLI final

Última pasada antes de generar el `.docx`:

- Invocar `verificacion-ecli-skill` con la lista de ECLI citados.
- Si alguno falla → eliminar del escrito y rehacer el bloque.
- Solo cuando 100% de los ECLI estén verificados → generar Word y entregar.

## 6. Entrega al usuario

Cuando el `.docx` esté generado:

```
[Demanda lista para presentar](computer://[ruta absoluta del .docx])

Resumen:
- Procedimiento: [X]
- Tribunal: [X]
- Cuantía: [X] €
- 5 STS verificadas con ECLI.
- Pasada de estilo Carlos aplicada.
- Listo para firmar y presentar vía LexNET.
```

Sin postamble extenso. Carlos abre el Word y revisa.
