# FASE 0 — Recopilación documental

> **Regla**: nunca abrir la Fase 1 (batería de preguntas) sin tener claro qué documentación hay y qué falta. La calidad del HECHO numerado y de la prueba documental depende de esta fase.

## Filosofía

La fase 0 no es una formalidad. Es la fase que **evita inventar hechos**. Si Carlos no aporta la documentación clave, la demanda no se puede redactar con la profundidad que la skill exige. Mejor parar aquí, listar lo que falta, y reanudar cuando llegue el material.

## Checklist documental por tipo de demanda

### Reclamación de cantidad / Monitorio / Verbal

- Contrato de origen de la deuda (suministro, servicios, obra, préstamo, etc.).
- Factura(s) impagada(s) — todas las relevantes, en orden cronológico.
- Albaranes de entrega o partes de obra firmados.
- Justificantes de pagos parciales (si los hay) — descontar siempre del principal.
- Comunicaciones previas con el deudor (emails, burofax, llamadas registradas).
- **MASC**: burofax con acuse de recibo + certificación de contenido o, en su defecto, declaración responsable del art. 264.4 LEC.
- Cuadro de intereses: tipo aplicable (legal del dinero, mora art. 7 Ley 3/2004, pactado), fecha desde la que se devengan, capitalización si procede.

### Desahucio (impago o expiración)

- Contrato de arrendamiento (con todas las prórrogas y addenda).
- Recibos de las rentas pagadas y certificación de las impagadas.
- Requerimiento previo del art. 22.4 LEC (si se pretende cerrar la enervación) con oferta de negociación que cumpla MASC.
- Comunicaciones con el arrendatario (emails, burofax, WhatsApp con certificación si aporta valor).
- Si es por expiración: comunicación de la voluntad de no renovar con la antelación legal (art. 10 LAU).
- Inventario de la vivienda (si se incluye reclamación accesoria de daños).

### Familia (divorcio contencioso, modificación de medidas, alimentos)

- Certificado de matrimonio.
- Libro de familia.
- Certificados de nacimiento de los hijos.
- Convenio anterior (si se modifica) o sentencia previa.
- Tres últimas nóminas de cada cónyuge / declaración IRPF / vida laboral.
- Patrimonio: notas simples del Registro de la Propiedad, extractos bancarios, vehículos.
- Pruebas de necesidades de los hijos: matrícula, gastos médicos, extraescolares.
- Si hay violencia de género: orden de protección o sentencia penal (excepción al MASC).

### Mercantil / Responsabilidad civil

- Contrato mercantil completo + anexos.
- Informe pericial técnico o médico (si procede).
- Atestado de la Guardia Civil/Policía o informe técnico.
- Pólizas de seguro relevantes.
- Comunicaciones formales entre empresas.
- Cuadro de daños y perjuicios desglosado por concepto.

### Propiedad horizontal

- Certificación de la deuda expedida por el Secretario-Administrador (con el visto bueno del Presidente).
- Acta de la junta donde se aprobó la liquidación.
- Notificación al deudor del acuerdo y de la deuda.
- Estatutos de la comunidad (si están en discusión).
- Si es impugnación de acuerdo: acta completa, convocatoria, asistencia, voto del comunero impugnante.

### Cláusulas abusivas / Consumidores

- Contrato bancario o de consumo completo.
- Reclamación previa al servicio de atención al cliente.
- Reclamación al organismo supervisor (Banco de España, CNMV, DGS) — esta puede valer como MASC si tiene resolución.
- Documentación de los pagos realizados al amparo de la cláusula impugnada.

## Acreditación del MASC — qué buscar

Toda demanda lleva como anexo un documento que acredite el cumplimiento del art. 5 LO 1/2025, salvo que entre en la excepción del art. 5.3. Los medios válidos según la jurisprudencia menor unificada son:

1. Burofax con acuse de recibo y certificación de contenido (estándar de oro).
2. Correo certificado con acuse de recibo + acreditación integral.
3. Acta de mediación o conciliación (privada, notarial o registral).
4. Certificación del tercero neutral (mediador, conciliador, experto independiente).
5. Oferta vinculante confidencial del art. 17 LO 1/2025 con justificante de remisión y recepción.
6. Comunicación entre letrados con acuse de lectura y burofax de respaldo.
7. Reclamación a organismo supervisor (consumidores) con resolución.
8. Reclamación del art. 7 LRCSCVM a aseguradora (circulación de vehículos).

**No valen** (criterio unificado): WhatsApp sin certificación, email simple sin acuse, llamadas telefónicas, comunicaciones verbales.

## Cuándo NO hay que aportar MASC

Comprobar siempre las excepciones tasadas del art. 5.3 LO 1/2025 (ver `excepciones.md`) antes de exigir documentación al cliente:

- Medidas cautelares previas a la demanda.
- Procedimientos de jurisdicción voluntaria.
- Tutela sumaria de posesión.
- Concurso de acreedores.
- Acciones colectivas.
- Demandas contra Administraciones Públicas.
- Materia laboral o penal.
- Monitorio europeo y proceso europeo de escasa cuantía.

En estos casos no se exige el documento, pero **sí se justifica expresamente la excepción** en el HECHO de cumplimiento del MASC (que pasa a ser un HECHO de exclusión del requisito).

## Output de esta fase

Antes de pasar a la Fase 1, devolver a Carlos un **listado breve** con:

- ✅ Documentos que ya tienes.
- ⚠️ Documentos que faltan y que **bloquean** la redacción.
- 🟡 Documentos opcionales que mejorarían la calidad pero no bloquean.

Ejemplo:

```
DOCUMENTACIÓN RECOPILADA — RECLAMACIÓN DE CANTIDAD ABC, S.L. ↔ XYZ, S.A.

✅ Contrato de suministro de 12-03-2024 (Doc. 1).
✅ Facturas nº 240/24, 241/24 y 245/24 (Doc. 2-4).
✅ Burofax MASC de 22-01-2026 con acuse y certificación (Doc. 5).
⚠️ Falta: justificantes de los pagos parciales que el cliente menciona (necesarios para descontar del principal).
🟡 Mejoraría: emails posteriores al burofax si los hay.
```
