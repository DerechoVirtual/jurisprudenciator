# FASE 1 — Batería de preguntas obligatoria antes de redactar

> **Regla cardinal**: NUNCA redactar sin haber agotado las baterías. Cada batería se ejecuta con `AskUserQuestion`. Las baterías van en orden y no se avanza a la siguiente sin respuesta de la actual.

## Filosofía

- Pregunta TODO lo que la demanda necesita y no se sabe con certeza.
- Si el dato es obvio del contexto previo, **no repreguntar** — pero confirmar siempre los críticos (fechas, nº autos, importes, NIF).
- Si Carlos da poca información inicial, **no improvisar** ni rellenar con "ejemplo".
- Si Carlos dice "redacta ya" sin completar las baterías → recordar la regla cardinal y proponer una versión exprés diferenciada (pero ofrecer siempre primero la vía completa).

---

## Batería 1 — Posición y tipo de demanda (OBLIGATORIA SIEMPRE)

| Pregunta | Header (≤12) | Opciones |
| --- | --- | --- |
| ¿Qué tipo de demanda interpones? | Tipo demanda | Reclamación cantidad / Desahucio / Familia / Mercantil / Propiedad horizontal / Otro |
| ¿Qué procedimiento corresponde por cuantía? | Procedimiento | Monitorio (≤250.000 €) / Verbal (≤15.000 €) / Ordinario (>15.000 €) / Verbal por materia (250 LEC) / Indeterminada |
| ¿Tu cliente es persona física o jurídica? | Cliente | Persona física / Persona jurídica / Comunidad de propietarios / Asociación |
| ¿La parte demandada es persona física o jurídica? | Demandado | Persona física / Persona jurídica / Plural (varios demandados) |

**Texto libre tras la batería:**
- Resumen del caso en 3-5 frases (qué pasó, qué pide el cliente).
- Importe principal reclamado en euros (si aplica).

---

## Batería 2 — Datos identificativos del caso (OBLIGATORIA SIEMPRE)

Combinada: parte vía `AskUserQuestion`, parte texto libre.

**Texto libre (pedir todos juntos):**
- Nombre, apellidos y DNI/NIE/CIF del actor (cliente).
- Domicilio del actor.
- Nombre, apellidos y DNI/NIE/CIF del demandado.
- Último domicilio conocido del demandado.
- Nombre y nº de colegiado del Procurador (si lo hay).
- Nombre y nº de colegiado del Letrado.
- Tribunal de Instancia competente (localidad + sección).
- Dirección electrónica para notificaciones (LexNET).

**`AskUserQuestion`:**

| Pregunta | Header | Opciones |
| --- | --- | --- |
| ¿Tu cliente tiene Justicia Gratuita reconocida? | Justicia Gratuita | Sí (exenta tasa) / No / En tramitación |
| ¿El demandado tiene domicilio conocido? | Domicilio | Sí, completo / Sí, último conocido / No (declaración 264.4) |
| ¿Régimen económico matrimonial (si es familia)? | REM | Gananciales / Separación de bienes / Participación / Otro / No aplica |

---

## Batería 3 — MASC (OBLIGATORIA SALVO EXCEPCIÓN del art. 5.3 LO 1/2025)

| Pregunta | Header | Opciones |
| --- | --- | --- |
| ¿Ya se hizo el intento de negociación previa? | MASC hecho | Sí (con respuesta negativa) / Sí (sin respuesta tras 30 días) / No (entra en excepción) / No (toca hacerlo aún) |
| ¿Por qué medio se intentó? | Medio MASC | Burofax con acuse / Correo certificado / Mediación / Comunicación entre letrados / Oferta vinculante / Reclamación a organismo supervisor / Otro |
| ¿Qué documento puedes aportar? | Doc MASC | Burofax + acuse / Acta mediación / Certificación tercero / Resolución organismo / Declaración responsable 264.4 |
| Si no se ha hecho ¿quieres que prepare el modelo de comunicación? | Modelo | Sí (burofax) / Sí (carta entre letrados) / Sí (oferta vinculante) / No |

**Texto libre tras la batería:**
- Fecha del intento MASC y, si la hay, fecha de la respuesta negativa.
- Si entra en excepción: cuál (ver `excepciones.md`).

---

## Batería 4 — Hechos y prueba (OBLIGATORIA SIEMPRE)

**Texto libre estructurado:**
- Cronología de los hechos en orden numerado (al menos 5 hitos: cuándo nació la relación jurídica, cuándo se incumplió, qué reclamaciones extrajudiciales hubo, etc.).
- Lista numerada de documentos disponibles (Doc. 1, Doc. 2…).
- ¿Hay testigos? Nombres y qué pueden declarar.
- ¿Hay pericial? Quién la firma, sobre qué.

| Pregunta | Header | Opciones |
| --- | --- | --- |
| ¿Quieres proponer interrogatorio del demandado? | Interrogatorio | Sí / No / Solo si contesta sin allanarse |
| ¿Hay informe pericial? | Pericial | Sí, ya lo tenemos / Sí, lo solicitaremos al juez / No procede |
| ¿Hay testigos clave? | Testigos | Sí (1-2) / Sí (3 o más) / No |

---

## Batería 5 — Pretensión y suplico (OBLIGATORIA SIEMPRE)

| Pregunta | Header | Opciones |
| --- | --- | --- |
| ¿Cuantía principal? | Principal | < 2.000 € / 2.000-15.000 € / 15.000-50.000 € / 50.000-250.000 € / > 250.000 € / Indeterminada |
| ¿Intereses que pides? | Intereses | Legales (art. 1108 CC) / Mora art. 7 Ley 3/2004 / Pactados en contrato / Procesales art. 576 LEC / No procede |
| ¿Pides condena en costas por temeridad (art. 394.2 LEC)? | Costas temeridad | Sí (alegar) / No (vencimiento normal) |
| ¿Hay pretensión subsidiaria? | Subsidiaria | Sí (preparar) / No |

**Texto libre:**
- Redacción exacta de la pretensión principal del suplico.
- Redacción exacta de la pretensión subsidiaria (si la hay).
- Cuantificación detallada (principal + intereses + IVA + lo que sea).

---

## Batería 6 — Otrosíes y trámite (OBLIGATORIA SIEMPRE)

| Pregunta | Header | Opciones |
| --- | --- | --- |
| ¿Solicitas medidas cautelares? | Cautelares | Sí (previas) / Sí (coetáneas) / No |
| ¿Acompañas dictamen pericial (art. 336 LEC) o pides designación judicial (art. 339)? | Pericial | Acompaño / Pido designación / Las dos cosas / No procede |
| ¿Solicitas vista oral (verbal/familia)? | Vista | Sí / No / Solo si el tribunal lo estima |
| ¿Necesitas otrosí de subsanación de defectos formales? | Subsanación | Sí (anticiparlo) / No |

---

## Batería 7 — Jurisprudencia y formato final (OBLIGATORIA SIEMPRE)

| Pregunta | Header | Opciones |
| --- | --- | --- |
| ¿Quieres jurisprudencia STS verificada (5 mínimo)? | Jurisprudencia | Sí (vía vLex) / Sí (vía CENDOJ) / No (modelo base) |
| ¿Quieres también SAP de la AP competente? | SAP | Sí, 1-2 / Sí, 3+ / No |
| Extensión deseada en palabras | Extensión | Estándar (3.000-5.000) / Extensa (5.000-8.000) / Muy extensa (>8.000) |
| ¿Aplico estilo Carlos en la pasada final? | Estilo | Sí (obligatorio) / No (versión neutra) |

---

## Cierre de la fase

Antes de pasar a la Fase 2, **resumir a Carlos en pantalla** los datos clave recogidos para que confirme. Si Carlos detecta un error, corregir antes de seguir.

Ejemplo de resumen:

```
RESUMEN DE LA FASE 1

Tipo: Reclamación de cantidad — Juicio Verbal
Cliente: D. Juan Pérez García (DNI 12345678X) frente a Construcciones SL (CIF B-87654321)
Tribunal: Tribunal de Instancia de Madrid, Sección Civil
Letrado: Carlos Rivero (ICAM 67890) | Procurador: Juan Sánchez (Col. 4321)
MASC: Burofax de 12-02-2026 con acuse, sin respuesta tras 30 días — Doc. 5
Cuantía: 12.450,00 € + intereses legales desde 01-01-2026 + costas
Suplico: Condena al pago de 12.450 € + intereses + costas
Otrosíes: cuantía, prueba documental + interrogatorio, dirección LexNET
Jurisprudencia: 5 STS vía vLex + 2 SAP Madrid
Estilo: Carlos | Extensión: estándar (~4.500 palabras)

¿Confirmas? (sí / hay que cambiar algo)
```
