# Checklist final antes de entregar la demanda

> **Regla**: si alguno de estos puntos falla, no se entrega. Se vuelve a la fase correspondiente y se corrige.

## 1. Encabezamiento y formalidades

- [ ] Encabezamiento al **Tribunal de Instancia** correcto, con sección.
- [ ] Localidad coincide con el fuero competente (verificar art. 50-52 LEC).
- [ ] Comparecencia con datos completos del procurador (si preceptivo) y letrado.
- [ ] Dirección electrónica para notificaciones LexNET designada.
- [ ] Identificación completa de actor y demandado (nombre/razón social, NIF/CIF, domicilio).

## 2. MASC y procedibilidad

- [ ] HECHO específico de cumplimiento del MASC numerado.
- [ ] Documento 264.4 LEC adjuntado y referenciado en el HECHO.
- [ ] Si entra en excepción del art. 5.3 LO 1/2025: justificada expresamente.
- [ ] Si hay declaración responsable por domicilio desconocido: gestiones de localización descritas.

## 3. Hechos

- [ ] Numerados correlativamente con ordinal escrito.
- [ ] Cronología clara (origen → cumplimiento → incumplimiento → reclamación → cuantificación).
- [ ] Cada hecho relevante referenciado a un Documento.
- [ ] Sin valoraciones jurídicas en los HECHOS (esas van en los FD).

## 4. Fundamentos de Derecho

- [ ] FD I — Competencia objetiva y territorial.
- [ ] FD II — Legitimación activa y pasiva.
- [ ] FD III — Procedimiento aplicable.
- [ ] FD IV — Postulación procesal.
- [ ] FD V — MASC (cumplimiento o excepción).
- [ ] FD VI — Fondo (con jurisprudencia STS).
- [ ] FD VII — Costas e intereses.
- [ ] Cada FD sustantivo termina con párrafo de **subsunción** a los hechos.

## 5. Jurisprudencia

- [ ] Mínimo **5 STS** citadas.
- [ ] Cada una con **ECLI verificado** en vLex/CENDOJ.
- [ ] Cada una con cita literal corta (15-35 palabras) entre comillas latinas.
- [ ] Cada una con párrafo de aplicación al caso concreto.
- [ ] Skill `verificacion-ecli-skill` ejecutada y todas las citas confirmadas.

## 6. Suplico

- [ ] Verbos rectores en mayúsculas y negrita (ESTIME, CONDENE, DECLARE).
- [ ] Peticiones numeradas con ordinal escrito.
- [ ] Importes líquidos o liquidables.
- [ ] Intereses pedidos con base normativa (art. 1108 CC, art. 7 Ley 3/2004, art. 576 LEC).
- [ ] Condena en costas pedida (con o sin temeridad).
- [ ] Pretensión subsidiaria (si procede) claramente marcada.

## 7. Otrosíes

- [ ] Otrosí de cuantía y procedimiento.
- [ ] Otrosí de prueba (anuncio art. 265.1 LEC).
- [ ] Otrosí de dirección electrónica (LexNET).
- [ ] Otrosí de medidas cautelares (si procede).
- [ ] Otrosí de justicia gratuita (si procede).
- [ ] Cada otrosí con suplico autónomo en mayúsculas.

## 8. Estilo

- [ ] Skill `estilo-carlos-escritos-judiciales` ejecutada.
- [ ] Sin adjetivos vacíos ("manifiestamente", "palmariamente", etc.) salvo justificación.
- [ ] Estructura tripartita en los hechos y en al menos un FD.
- [ ] Cierre estratégico al final de cada FD sustantivo.
- [ ] Verbos rotados (anti-muletilla).

## 9. Formato Word

- [ ] Times New Roman 12 pt.
- [ ] Interlineado 1,15.
- [ ] Márgenes 3/2,5/2,5/2,5 cm.
- [ ] Encabezamiento centrado y en negrita.
- [ ] Títulos de sección centrados con espaciado entre letras.
- [ ] Numeración ordinal escrita.
- [ ] ECLI en negrita entre corchetes.
- [ ] Citas literales con comillas latinas.
- [ ] Pie de firma a dos columnas.
- [ ] Numeración de páginas.

## 10. Documentos acompañados

- [ ] Lista numerada al final con "Doc. [N].- [descripción]".
- [ ] Doc. 1 = Poder general (si procuradores preceptivos).
- [ ] Doc. final = Acreditación MASC.
- [ ] Todos los documentos referenciados en los HECHOS coinciden con los enumerados.

## 11. Entrega

- [ ] Archivo `.docx` generado y guardado en outputs/.
- [ ] Enlace `computer://[ruta]` ofrecido a Carlos.
- [ ] Resumen ejecutivo (5-10 líneas) acompañando el enlace.
- [ ] Sin postamble extenso ("aquí tienes la demanda…lista para…").

## 12. Si algo falla

Si cualquier punto del 1 al 10 falla → no se entrega. Se vuelve a la fase correspondiente:

- Falla 1-2 → Fase 0/2.
- Falla 3-4 → Fase 5 (redacción).
- Falla 5 → Fase 4 (jurisprudencia).
- Falla 6-7 → Fase 3 (estrategia).
- Falla 8 → invocar de nuevo `estilo-carlos-escritos-judiciales`.
- Falla 9-10 → regenerar el Word.
