# Requisitos por Tipo de Procedimiento

## Índice
1. [Juicio Ordinario](#juicio-ordinario)
2. [Juicio Verbal](#juicio-verbal)
3. [Monitorio](#monitorio)
4. [Desahucio](#desahucio)
5. [Ejecución de Títulos](#ejecución-de-títulos)
6. [Familia](#familia)
7. [Cambiario](#cambiario)

---

## Juicio Ordinario

**Cuantía**: Superior a 15.000€ o materia no atribuida a verbal.

**Postulación**: Abogado y procurador preceptivos.

**Documentos obligatorios**:
1. Poder general/especial para pleitos (art. 264.1 LEC)
2. Documentos en que funde su derecho (art. 264.2 LEC)
3. Dictámenes periciales (art. 264.3 LEC)
4. **Documento MASC o declaración responsable (art. 264.4 LEC)**

**Contenido demanda** (art. 399 LEC):
- Datos identificativos partes
- Hechos numerados
- Fundamentos de derecho
- Peticiones claras y precisas
- **Descripción proceso negociación previa (art. 399.3 LEC)**

**Plazos**:
- Contestación: 20 días
- Audiencia previa: señalamiento judicial
- Juicio: señalamiento tras audiencia

---

## Juicio Verbal

**Cuantía**: Hasta 15.000€ o materias del art. 250 LEC.

**Postulación**:
- ≤ 2.000€: no preceptiva
- > 2.000€: abogado y procurador preceptivos

**Materias específicas** (art. 250 LEC):
- Arrendamientos urbanos (cualquier cuantía)
- Precario
- Tutela posesión/tenencia
- Rectificación de hechos
- Alimentos entre parientes
- Propiedad horizontal

**Documentos**: Mismos que ordinario.

**Trámite reformado LO 1/2025**:
- Posible tramitación escrita sin vista
- Vista solo si partes lo solicitan o tribunal lo estima necesario
- Auto resolutorio de cuestiones procesales

---

## Monitorio

**Requisitos** (art. 812 LEC):
- Deuda dineraria, vencida, exigible
- Cuantía determinada
- No superior a 250.000€

**MASC**: **Sí obligatorio** salvo monitorio de comunidades de propietarios (discutido).

**Documentos acreditativos**:
- Facturas
- Albaranes
- Certificaciones
- Telegramas, fax
- Cualquier documento firmado por deudor

**Comunidades de propietarios** (art. 21 LPH):
- Certificación deuda expedida por secretario
- Acta junta aprobando liquidación
- Notificación al deudor

---

## Desahucio

### Por falta de pago (art. 440 LEC)

**Competencia**: Tribunal de Instancia del lugar del inmueble.

**MASC**: Obligatorio. El requerimiento del art. 22.4 LEC puede cumplir el requisito si incluye oferta de negociación.

**Acumulación de acciones**: Puede acumularse reclamación de rentas.

**Documentos**:
- Contrato de arrendamiento
- Requerimiento previo de pago (art. 22.4 LEC)
- Documento MASC
- Certificado de deuda

**Enervación**: El arrendatario puede enervar pagando antes de la vista (una sola vez).

### Por expiración plazo

**MASC**: Obligatorio.

**Documentos**:
- Contrato con fecha expiración
- Requerimiento de desalojo
- Documento MASC

---

## Ejecución de Títulos

### Títulos judiciales (art. 517.1 LEC)
- Sentencias firmes
- Laudos arbitrales
- Resoluciones judiciales que aprueben transacciones

### Títulos no judiciales (art. 517.2 LEC)
- Escrituras públicas
- Pólizas intervenidas por notario
- Títulos al portador o nominativos

**MASC**: **No obligatorio** para ejecución de títulos ejecutivos.

**Demanda ejecutiva**:
- Título ejecutivo
- Liquidación de deuda
- Bienes del ejecutado (si se conocen)

---

## Familia

**Competencia**: Sección de Familia, Infancia y Capacidad del Tribunal de Instancia.

### Divorcio/Separación contencioso

**MASC**: Obligatorio, incluso para medidas sobre menores (con homologación judicial).

**Documentos**:
- Certificado de matrimonio
- Certificados de nacimiento de hijos
- Propuesta de convenio regulador (o medidas solicitadas)
- Documento MASC

### Divorcio/Separación de mutuo acuerdo

**MASC**: No necesario (ya hay acuerdo).

**Vía notarial**: Posible si no hay hijos menores no emancipados.

### Modificación de medidas

**MASC**: Obligatorio.

**Requisito**: Alteración sustancial de circunstancias.

### Medidas provisionales previas (art. 771 LEC)

**MASC**: Obligatorio según art. 5.1 LO 1/2025.

---

## Cambiario

**Títulos**: Letra de cambio, cheque, pagaré.

**Competencia**: Domicilio del demandado (art. 820 LEC).

**MASC**: Obligatorio.

**Documentos**:
- Original del título cambiario
- Documento MASC

**Especialidades**:
- Ejecución directa si título reúne requisitos
- Embargo preventivo posible

---

## Cuadro resumen MASC por procedimiento

| Procedimiento | MASC obligatorio | Excepciones |
|--------------|------------------|-------------|
| Ordinario | ✅ Sí | Medidas cautelares previas |
| Verbal | ✅ Sí | Tutela sumaria posesión |
| Monitorio | ✅ Sí | Monitorio europeo |
| Desahucio | ✅ Sí | - |
| Ejecución | ❌ No | - |
| Familia contencioso | ✅ Sí | - |
| Familia mutuo acuerdo | ❌ No | - |
| Cambiario | ✅ Sí | - |
| Jurisdicción voluntaria | ❌ No | - |
