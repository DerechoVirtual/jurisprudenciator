# Excepciones al MASC y Casos Especiales

## Índice
1. [Excepciones legales expresas](#excepciones-legales-expresas)
2. [Conflictos transfronterizos](#conflictos-transfronterizos)
3. [Materias excluidas](#materias-excluidas)
4. [Consumidores](#consumidores)
5. [Circulación de vehículos](#circulación-de-vehículos)
6. [Propiedad horizontal](#propiedad-horizontal)
7. [Criterios judiciales unificados](#criterios-judiciales-unificados)

---

## Excepciones legales expresas

El artículo 5.3 de la LO 1/2025 establece que **NO será necesario** acudir a MASC:

### a) Medidas cautelares previas a la demanda
- Embargo preventivo
- Anotación preventiva de demanda
- Intervención judicial de bienes

### b) Solicitud de medidas urgentes del art. 158 CC
- Medidas de protección de menores
- Medidas en situaciones de riesgo

### c) Medidas de apoyo a personas con discapacidad

### d) Procedimientos de jurisdicción voluntaria
- Expedientes de dominio
- Actas de notoriedad
- Habilitación para comparecer en juicio

### e) Tutela sumaria de posesión/tenencia
- Interdictos posesorios
- Acción de recobrar la posesión

### f) Demolición de obra ruinosa

### g) Menores
- Ingreso de menores con problemas de conducta
- Restitución en sustracción internacional

### h) Violencia de género/doméstica
- Órdenes de protección
- Medidas civiles derivadas

### i) Acciones colectivas (art. 11 LEC)

### j) Procedimiento concursal

### k) Acumulación subjetiva de acciones

---

## Conflictos transfronterizos

**Definición** (art. 3 Ley 5/2012): Conflicto donde al menos una de las partes tiene domicilio en Estado miembro distinto.

### Excepciones específicas (art. 5.3 LO 1/2025):

**NO requieren MASC**:
- Monitorio europeo (Reglamento CE 1896/2006)
- Proceso europeo de escasa cuantía (Reglamento CE 861/2007)

**SÍ requieren MASC**:
- Resto de procedimientos civiles/mercantiles transfronterizos
- Cuando una parte tenga domicilio en España y la negociación se realice en España

### Cuestiones prácticas:
- La ley procesal aplicable es la del foro (territorialidad)
- Dudas sobre si ambos requisitos (domicilio + negociación en España) son conjuntos
- Recomendación: cumplir MASC cuando haya conexión española

---

## Materias excluidas

El artículo 3.2 de la LO 1/2025 **excluye del ámbito de aplicación**:

### Exclusiones absolutas:
1. **Materia laboral** - Competencia jurisdicción social
2. **Materia penal** - Incluida responsabilidad civil derivada de delito
3. **Materia concursal** - Ley Concursal
4. **Sector público** - Demandas contra Administraciones Públicas

### Consecuencias:
- No hay requisito de procedibilidad
- No aplicación de efectos sobre costas del art. 7 LO 1/2025
- Demanda directa sin negociación previa

---

## Consumidores

### Régimen especial (Disp. Adicional 7ª LO 1/2025)

**Se entiende cumplido el MASC** cuando el consumidor haya:

1. **Servicios financieros**:
   - Reclamación ante Banco de España
   - Reclamación ante CNMV
   - Reclamación ante DGS y Fondos de Pensiones
   (Art. 30 Ley 44/2002)

2. **Consumo general**:
   - Procedimientos de la Ley 7/2017 (entidades RAL)
   - Arbitraje de consumo

### Importante:
- La resolución del organismo supervisor cumple el requisito
- No es necesario negociación adicional
- Conservar resolución/dictamen para adjuntar a demanda

---

## Circulación de vehículos

### Reclamación previa a aseguradora (art. 7 LRCSCVM)

**Criterio judicial unificado**: La reclamación del art. 7 LRCSCVM **cumple el requisito MASC** si:
- Se presenta dentro del plazo de 1 año
- Se dirige a la aseguradora del responsable
- Incluye documentación de daños

### Casos especiales:
- **Varios responsables**: Reclamación separada a cada aseguradora
- **Fondo de Garantía**: Reclamación previa al Consorcio
- **Vehículo no asegurado**: Reclamación al propietario + Consorcio

### Plazo de espera:
- 3 meses desde reclamación sin respuesta = cumplido

---

## Propiedad horizontal

### Monitorio de comunidades (art. 21 LPH)

**Controversia interpretativa**:

**Posición 1** (Algunos juzgados): No requiere MASC adicional porque:
- Art. 21 LPH no fue modificado
- Documentación específica ya regulada
- Naturaleza especial del procedimiento

**Posición 2** (Posición mayoritaria): SÍ requiere MASC porque:
- No hay excepción expresa en art. 5.3 LO 1/2025
- Requisito general de procedibilidad

**Recomendación práctica**: Incluir requerimiento previo al deudor con oferta de negociación/pago fraccionado.

### Impugnación de acuerdos

**SÍ requiere MASC**: Al ser acción declarativa ordinaria.

**Plazo de caducidad**: 1 año desde adopción del acuerdo.

**Problema práctico**: El plazo MASC (30 días) puede comprometer el plazo de caducidad.

**Solución**: Iniciar MASC inmediatamente tras el acuerdo impugnado.

---

## Criterios judiciales unificados

### Junta de Jueces de Barcelona (8/4/2025)

1. **Desahucio por impago**: El requerimiento del art. 22.4 LEC puede cumplir el MASC si incluye voluntad negociadora clara y transparente.

2. **Oferta vinculante**: No basta la mera oferta; debe haber actividad negociadora verificable.

3. **Excepción procesal**: Se articula en audiencia previa (ordinario) o vista (verbal).

### Junta Sectorial de Zamora (2/4/2025)

**Medios válidos de acreditación**:
- Mediación con documento del tercero
- Conciliación pública o privada
- Oferta vinculante con justificante remisión/recepción
- Burofax/BuroMail/BuroSMS
- Correo certificado con acreditación integral

**Medios NO válidos**:
- WhatsApp sin certificación
- Email sin acuse de recibo

### Audiencia Provincial de Valencia (21/5/2025)

**Derecho transitorio**: El momento relevante es la **fecha de presentación de la demanda**, no la fecha de incoación del procedimiento.

- Demandas presentadas antes del 3/4/2025: No requieren MASC
- Demandas presentadas desde 3/4/2025: Sí requieren MASC

### Audiencia Provincial de Oviedo (Auto 97/2025)

**Sistematización del requisito**:

1. **Insubsanable**: La falta de intento negociador previo a la demanda
2. **Subsanable**: La falta de aportación documental (con plazo breve)
3. **Identidad objeto**: Debe coincidir objeto negociación y objeto litigio
4. **Buena fe**: Valoración de diligencia en localización del requerido

---

## Resumen práctico

| Supuesto | ¿MASC? | Observaciones |
|----------|--------|---------------|
| Medidas cautelares previas | ❌ No | Excepción expresa |
| Jurisdicción voluntaria | ❌ No | Excepción expresa |
| Tutela sumaria posesión | ❌ No | Excepción expresa |
| Concurso | ❌ No | Materia excluida |
| Laboral/Penal | ❌ No | Materia excluida |
| Sector público | ❌ No | Materia excluida |
| Monitorio europeo | ❌ No | Excepción transfronteriza |
| Consumidores (tras RAL) | ✅ Cumplido | Con resolución organismo |
| Circulación (tras art. 7) | ✅ Cumplido | Con reclamación previa |
| Monitorio PH | ⚠️ Discutido | Recomendado incluir |
| Resto procedimientos | ✅ Sí | Regla general |
