# Modelos de Comunicación MASC

Modelos de requerimientos y comunicaciones para cumplir el requisito de procedibilidad.

---

## 1. Burofax de reclamación con oferta de negociación

```
BUROFAX CON ACUSE DE RECIBO Y CERTIFICACIÓN DE CONTENIDO

REMITENTE:
[Nombre completo]
[DNI/NIF]
[Dirección completa]
[Teléfono y email]

DESTINATARIO:
[Nombre completo / Razón social]
[NIF/CIF]
[Dirección completa]

En [localidad], a [fecha]

ASUNTO: REQUERIMIENTO DE PAGO Y OFERTA DE NEGOCIACIÓN EXTRAJUDICIAL

Muy Sr./Sra. mío/a:

Por medio de la presente, le comunico que mantiene una deuda pendiente conmigo 
por importe de [CANTIDAD] EUROS ([cantidad en letra] euros), correspondiente a 
[concepto de la deuda: factura nº X, contrato de fecha X, etc.].

Dicha cantidad debió ser abonada en fecha [fecha de vencimiento], encontrándose 
actualmente vencida y siendo exigible.

REQUERIMIENTO DE PAGO:
Le requiero formalmente para que proceda al pago de la cantidad adeudada en el 
plazo máximo de QUINCE (15) DÍAS desde la recepción de este escrito.

OFERTA DE NEGOCIACIÓN (art. 5 LO 1/2025):
Conforme a lo establecido en la Ley Orgánica 1/2025, de 2 de enero, y antes de 
acudir a la vía judicial, le ofrezco la posibilidad de alcanzar un acuerdo 
extrajudicial que evite los costes y dilaciones de un procedimiento judicial.

A tal efecto, le propongo:
[ ] Pago íntegro de la deuda
[ ] Pago fraccionado en [X] plazos mensuales
[ ] Negociación de las condiciones
[ ] Acudir a mediación

Le ruego contacte conmigo en el plazo de TREINTA (30) DÍAS para negociar una 
solución. Puede hacerlo a través de:
- Teléfono: [número]
- Email: [dirección]
- Correo postal: [dirección]

ADVERTENCIA:
Le informo que, de no atender este requerimiento ni manifestar su voluntad de 
negociar en el plazo indicado, se entenderá cumplido el requisito de 
procedibilidad del artículo 5 de la LO 1/2025, y procederé a interponer la 
correspondiente demanda judicial, reclamando además los intereses de demora, 
las costas procesales y cuantos gastos se deriven del procedimiento.

Sin otro particular, quedo a la espera de su respuesta.

Atentamente,

[Firma]
[Nombre completo]
```

---

## 2. Comunicación entre letrados

```
[MEMBRETE DEL DESPACHO]

[Localidad], [fecha]

ENVIADO POR CORREO ELECTRÓNICO CON ACUSE DE LECTURA
Y BUROFAX

Ilmo/a. Sr/a. Letrado/a
D./Dña. [Nombre del letrado contrario]
[Colegio de Abogados nº]
[Dirección]
[Email]

ASUNTO: Reclamación de D./Dña. [cliente] frente a [contraparte] - 
Requerimiento e invitación a negociación extrajudicial

Distinguido/a compañero/a:

Me dirijo a Vd. en nombre y representación de mi cliente, D./Dña. [nombre], 
en relación con la reclamación que mantiene frente a su representado/a.

ANTECEDENTES:
[Breve descripción de los hechos y la reclamación]

CANTIDAD RECLAMADA:
Principal: [cantidad] €
Intereses devengados: [cantidad] €
TOTAL: [cantidad] €

INVITACIÓN A NEGOCIACIÓN (ART. 5 LO 1/2025):
En cumplimiento del requisito de procedibilidad establecido en la Ley Orgánica 
1/2025, de 2 de enero, y con el fin de evitar un procedimiento judicial, le 
propongo entablar negociaciones para alcanzar un acuerdo extrajudicial.

Estamos abiertos a:
1. Reunión presencial o telemática para negociación directa
2. Acudir a mediación civil/mercantil
3. Someter la controversia a opinión de experto independiente
4. Cualquier otro MASC que consideren oportuno

Le ruego me comunique en el plazo de TREINTA (30) DÍAS si su representado/a 
está dispuesto a negociar y, en su caso, qué medio considera más adecuado.

Transcurrido dicho plazo sin respuesta, entenderemos cumplido el requisito de 
procedibilidad y procederemos a interponer la correspondiente demanda judicial.

Quedo a su disposición para cualquier aclaración.

Reciba un cordial saludo,

[Firma]
[Nombre del Letrado]
Abogado - Col. nº [número]
```

---

## 3. Acta de negociación fallida

```
ACTA DE NEGOCIACIÓN EXTRAJUDICIAL SIN ACUERDO

En [localidad], a [fecha].

REUNIDOS:

De una parte, D./Dña. [nombre], con DNI [número], [domicilio], asistido/a por 
el Letrado D./Dña. [nombre], colegiado nº [número] del ICAM/ICA[ciudad].

De otra parte, D./Dña. [nombre], con DNI [número], [domicilio], asistido/a por 
el Letrado D./Dña. [nombre], colegiado nº [número] del ICAM/ICA[ciudad].

OBJETO DE LA NEGOCIACIÓN:
[Descripción del conflicto: reclamación de cantidad, incumplimiento contractual, etc.]

DESARROLLO DE LA NEGOCIACIÓN:
Las partes han mantenido [número] sesiones de negociación en las siguientes fechas:
- [Fecha 1]: [Breve resumen]
- [Fecha 2]: [Breve resumen]

POSICIONES DE LAS PARTES:
- [Parte 1] mantiene que [posición]
- [Parte 2] mantiene que [posición]

RESULTADO:
Tras los intentos de negociación realizados, las partes NO HAN ALCANZADO ACUERDO, 
persistiendo la controversia en los términos expuestos.

EFECTOS:
El presente documento acredita el cumplimiento del requisito de procedibilidad 
establecido en el artículo 5 de la Ley Orgánica 1/2025, de 2 de enero, quedando 
expedita la vía judicial para cualquiera de las partes.

CONFIDENCIALIDAD:
Las partes se comprometen a mantener la confidencialidad sobre el contenido de 
las negociaciones, conforme al artículo 9 de la LO 1/2025, sin perjuicio de 
que pueda acreditarse el intento de negociación y su resultado.

Y para que conste, firman la presente en el lugar y fecha indicados.

[Firma Parte 1]              [Firma Parte 2]

[Firma Letrado 1]            [Firma Letrado 2]
```

---

## 4. Declaración responsable (domicilio desconocido)

```
DECLARACIÓN RESPONSABLE
(Art. 264.4 LEC)

D./Dña. [nombre completo], mayor de edad, con DNI nº [número] y domicilio en 
[dirección completa], actuando en su propio nombre y derecho [o en nombre y 
representación de...],

DECLARA RESPONSABLEMENTE:

PRIMERO.- Que pretende interponer demanda frente a D./Dña. [nombre del demandado] 
/ [Razón social], con [último domicilio conocido / NIF conocido].

SEGUNDO.- Que no ha sido posible llevar a cabo la actividad negociadora previa 
exigida por el artículo 5 de la Ley Orgánica 1/2025, de 2 de enero, por 
DESCONOCER EL DOMICILIO ACTUAL del demandado y el medio por el que puede ser 
requerido.

TERCERO.- Que ha realizado las siguientes gestiones para localizar al demandado:
[ ] Consulta del último domicilio conocido: [dirección] - Resultado: [negativo/
    devuelto/no reside]
[ ] Consulta en el Padrón Municipal de [localidad] - Resultado: [negativo/sin datos]
[ ] Consulta en el Registro Mercantil (si es persona jurídica) - Resultado: [...]
[ ] Búsqueda en directorios públicos/internet - Resultado: [negativo]
[ ] Otras gestiones: [especificar]

CUARTO.- Que, pese a las gestiones realizadas, no ha sido posible determinar 
un domicilio o medio de comunicación válido para dirigir la comunicación 
extrajudicial previa.

QUINTO.- Que la presente declaración se formula a los efectos de dar cumplimiento 
al artículo 264.4 de la Ley de Enjuiciamiento Civil, en relación con el artículo 
5 de la LO 1/2025, como requisito de procedibilidad para la admisión de la demanda.

Y para que así conste, firmo la presente declaración responsable.

En [localidad], a [fecha].

[Firma]
Fdo.: [Nombre completo]
```

---

## 5. Oferta vinculante confidencial (art. 17 LO 1/2025)

```
OFERTA VINCULANTE CONFIDENCIAL
(Art. 17 LO 1/2025)

REMITENTE:
D./Dña. [nombre] / [Razón social]
[Dirección]
Representado por Letrado: [nombre], Col. nº [número]

DESTINATARIO:
D./Dña. [nombre] / [Razón social]
[Dirección]

[Localidad], [fecha]

ASUNTO: OFERTA VINCULANTE CONFIDENCIAL - Art. 17 LO 1/2025

En relación con la controversia existente entre las partes relativa a 
[descripción del conflicto], y al amparo del artículo 17 de la Ley Orgánica 
1/2025, de 2 de enero, formulo la siguiente:

OFERTA VINCULANTE

PRIMERO.- Mi representado ofrece a la parte contraria el pago/abono de la 
cantidad de [CANTIDAD] EUROS ([en letra] euros), en concepto de [principal / 
principal más intereses / indemnización total].

SEGUNDO.- Dicha cantidad se abonará mediante [transferencia bancaria / cheque 
bancario / efectivo] en el plazo de [X] días desde la aceptación de esta oferta.

TERCERO.- La aceptación de esta oferta supondrá la renuncia recíproca de las 
partes a cualquier acción judicial derivada de [los hechos objeto de controversia].

CUARTO.- Esta oferta tiene carácter de OFERTA VINCULANTE CONFIDENCIAL conforme 
al artículo 17 de la LO 1/2025, por lo que:
- Es confidencial y no podrá ser utilizada como prueba en juicio
- Vincula al oferente durante [30/60/90] días desde su recepción
- Su no aceptación permitirá valorar la conducta de las partes a efectos de costas

PLAZO DE ACEPTACIÓN:
Esta oferta permanecerá vigente durante TREINTA (30) DÍAS desde su recepción.

Transcurrido dicho plazo sin aceptación expresa, quedará sin efecto, 
entendiéndose cumplido el requisito de procedibilidad del artículo 5 LO 1/2025.

Quedo a la espera de su respuesta.

[Firma del Letrado]
[Nombre]
Abogado Col. nº [número]
```

---

## Medios de envío válidos

Según criterios judiciales unificados, son válidos:

✅ **Aceptados**:
- Burofax con acuse de recibo y certificación de contenido
- Correo certificado con acuse de recibo
- Conducto notarial
- BuroMail / BuroSMS
- Acta de mediación/conciliación
- Comunicación entre letrados con acuse

❌ **No aceptados**:
- WhatsApp (sin certificación)
- Email simple sin acuse
- Llamadas telefónicas
- Comunicaciones verbales
