# FASE 2 — Análisis de viabilidad, competencia y MASC

> **Regla**: tras la fase 1 hay que mirar el caso de fuera, como letrado externo, y verificar que la demanda es viable, que el procedimiento es el adecuado, que el tribunal es competente y que el MASC está bien encajado. Si algo falla, decírselo a Carlos antes de redactar.

## 1. Procedimiento adecuado por cuantía y materia

### Por cuantía (art. 248-249 LEC)

| Cuantía | Procedimiento | Postulación |
| --- | --- | --- |
| ≤ 2.000 € | Verbal | No preceptiva |
| 2.001 € – 15.000 € | Verbal | Preceptiva (abogado y procurador) |
| > 15.000 € | Ordinario | Preceptiva |
| Indeterminada (cuantificable) | Según materia | Variable |
| Indeterminada absoluta | Ordinario | Preceptiva |

### Por materia (art. 250 LEC) — Verbal cualquiera que sea la cuantía

- Arrendamientos urbanos y rústicos.
- Tutela sumaria de la posesión y de los derechos reales inscritos.
- Precario.
- Rectificación de hechos inexactos y perjudiciales (Ley Orgánica 2/1984).
- Alimentos entre parientes.
- Propiedad horizontal (algunas acciones).
- Reclamaciones derivadas de contrato de seguro obligatorio de circulación.

### Monitorio (arts. 812 ss. LEC)

- Deuda dineraria.
- Vencida y exigible.
- Cuantía determinada (no superior a 250.000 € — sin límite superior tras la reforma).
- Acreditada por documento (factura, albarán, certificación, etc.).

### Cambiario (arts. 819 ss. LEC)

- Deuda derivada de letra de cambio, cheque o pagaré que cumpla los requisitos legales.

## 2. Competencia objetiva y territorial

### Objetiva

- Civil, Mercantil y Familia → Tribunal de Instancia (sección correspondiente).
- Concursal → Sección Mercantil del Tribunal de Instancia.
- Familia, infancia y capacidad → Sección de Familia.

### Territorial — fueros más frecuentes (arts. 50-52 LEC)

| Materia | Fuero |
| --- | --- |
| Regla general | Domicilio del demandado |
| Inmuebles (acciones reales) | Lugar donde está el inmueble |
| Sucesiones | Último domicilio del causante |
| Consumidores (acciones del consumidor) | Domicilio del consumidor |
| Arrendamientos urbanos/rústicos | Lugar del inmueble |
| Seguros | Domicilio del asegurado |
| Sociedades (acciones internas) | Domicilio social |
| Daños circulación | Lugar del hecho o domicilio del perjudicado |

### Sumisión

- Expresa (art. 55 LEC): válida en mercantil B2B.
- **Nula** en consumidores y arrendamientos.

## 3. MASC — encaje del caso

Antes de exigir al cliente la prueba documental, verificar:

1. ¿Entra en alguna excepción tasada del art. 5.3 LO 1/2025? Ver `excepciones.md`.
2. ¿Es materia excluida (laboral, penal, concursal, sector público)? → no procede MASC.
3. ¿Es consumidor con resolución de organismo supervisor? → ya cumplido (DA 7ª).
4. ¿Es circulación con reclamación del art. 7 LRCSCVM? → ya cumplido.
5. ¿Es PH con monitorio? → discutido, recomendado incluirlo igualmente.

Si no entra en excepción, **pedir al cliente** la prueba documental del intento. Si no la tiene, ofrecerle redactar el burofax o la carta entre letrados (modelos en `modelos-masc.md`).

## 4. Plazos críticos a comprobar

- **Caducidad / prescripción** de la acción.
- **Plazo MASC**: 30 días sin respuesta = cumplido (art. 10 LO 1/2025).
- **Enervación** en desahucio: el arrendatario puede enervar pagando hasta antes de la vista (una sola vez en cinco años).
- **Impugnación de acuerdos en propiedad horizontal**: 1 año desde la adopción del acuerdo (3 meses si es contrario a la ley).
- **Reclamación al Banco de España**: el plazo de respuesta del organismo descuenta del MASC.
- **Daños circulación**: 1 año (art. 1968 CC) — atención a si el plazo MASC compromete la prescripción.

## 5. Banderas rojas

Devolver a Carlos un dictamen de **luces verdes/rojas** antes de redactar. Si aparece una bandera roja, parar y consultar:

- 🚩 Cuantía mal calculada → puede llevar a procedimiento inadecuado.
- 🚩 Tribunal incompetente → declinatoria o nulidad.
- 🚩 Falta de MASC sin excepción aplicable → inadmisión a trámite.
- 🚩 Acción caducada o prescrita → desestimación.
- 🚩 Falta de legitimación (activa o pasiva) → desestimación.
- 🚩 Litisconsorcio pasivo necesario incompleto → indefensión y nulidad.
- 🚩 Cláusula de sumisión expresa que cambia el fuero territorial.

## 6. Output de esta fase

Devolver a Carlos un **dictamen de viabilidad** breve y claro:

```
DICTAMEN DE VIABILIDAD — Reclamación cantidad ABC ↔ XYZ

✅ Procedimiento: Verbal con postulación preceptiva (cuantía 12.450 €).
✅ Tribunal competente: Tribunal de Instancia de Madrid, Sección Civil (domicilio del demandado).
✅ MASC cumplido: burofax de 12-02-2026 sin respuesta tras 30 días.
✅ Acción no prescrita (1 año desde el último vencimiento, vencimientos posteriores a 06-2025).
✅ Legitimación clara (acreedor titular del crédito frente a deudor identificado).

LUZ VERDE para redactar.
```

Si hay banderas rojas:

```
DICTAMEN DE VIABILIDAD — Reclamación XYZ

🚩 La acción puede estar prescrita: el último impago es de 02-03-2024 y han pasado 23 meses.
🚩 No consta MASC y no hay excepción aplicable.

RECOMENDACIÓN: antes de redactar, decidir si:
   1. Se intenta cierre del cómputo de prescripción con un nuevo requerimiento (CC 1973).
   2. Se asume el riesgo y se interpone igualmente.

Espero tu indicación.
```
