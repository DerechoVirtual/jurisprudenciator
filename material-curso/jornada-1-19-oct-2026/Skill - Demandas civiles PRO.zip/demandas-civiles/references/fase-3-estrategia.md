# FASE 3 — Estrategia procesal

> **Regla**: una demanda no es solo "redactar lo que pide el cliente". Es decidir cómo se pide, qué se acompaña, qué se reserva para la vista, qué pretensiones subsidiarias se plantean y qué otrosíes blindan el escrito frente a defectos procesales.

## 1. Definición de la pretensión exacta

Antes de escribir nada del suplico, fijar con Carlos:

- **Pretensión principal**: redacción literal, cuantificada, líquida.
- **Pretensión subsidiaria**: cuándo se plantea (cuando la principal es jurídicamente discutible), cómo se redacta.
- **Intereses**:
  - Legales del dinero (art. 1108 CC).
  - De demora del art. 7 Ley 3/2004 (operaciones comerciales B2B).
  - Pactados en contrato (verificar que no son usurarios).
  - Procesales del art. 576 LEC (siempre que haya condena dineraria).
- **Costas**: por vencimiento (art. 394.1 LEC) o por temeridad (art. 394.2 LEC).
- **IVA**: si el cliente está obligado a repercutirlo, separar siempre principal e IVA.

### Cláusula tipo de suplico (modelo)

```
SUPLICO AL TRIBUNAL DE INSTANCIA: que tenga por presentada esta demanda y los 
documentos que la acompañan, se sirva admitirla, dándole el trámite del juicio 
[verbal / ordinario / monitorio], y previos los trámites legales, dicte 
sentencia por la que:

PRIMERO.- Estime íntegramente la presente demanda.

SEGUNDO.- Condene a la parte demandada a abonar a mi mandante:
   a) La cantidad de [PRINCIPAL] euros, en concepto de [concepto].
   b) Los intereses [legales / de demora / pactados] de la cantidad anterior, 
      desde [fecha] hasta su completo pago.
   c) Las costas procesales del presente procedimiento.

SUBSIDIARIAMENTE, y para el supuesto de que el tribunal no acoja la pretensión 
principal, procede [pretensión subsidiaria] en los términos expuestos en el 
HECHO [X] y FUNDAMENTO DE DERECHO [Y].

Es justicia que se pide en [lugar], a [fecha].
```

## 2. Estrategia probatoria

Decidir y dejar anotado, antes de redactar:

| Medio | Cuándo | Cómo se anuncia |
| --- | --- | --- |
| Documental | Siempre | Anexos numerados (Doc. 1, 2, 3…) + otrosí de prueba |
| Interrogatorio del demandado | Si hay hechos personales que confesar | Otrosí de prueba: "interrogatorio del legal representante de…" |
| Testifical | Hechos relevantes presenciados por terceros | Otrosí + lista con nombres y dirección |
| Pericial — aportada | Pericial técnica ya elaborada | Doc. + otrosí (art. 336 LEC) |
| Pericial — designación judicial | No hay pericial previa pero se necesita | Otrosí (art. 339 LEC) — anuncio expreso |
| Reconocimiento judicial | Inmuebles, daños in situ | Otrosí + razón de la solicitud |
| Reproducción de imágenes/sonido | Vídeos, audios | Otrosí + soporte adjunto |

## 3. Otrosíes que conviene incluir

| Otrosí | Para qué sirve | Cuándo |
| --- | --- | --- |
| Cuantía y procedimiento | Fijar cuantía y procedimiento para evitar contestación de declinatoria | SIEMPRE |
| Anuncio de prueba (art. 265.1 LEC) | Anunciar las pruebas que se propondrán | SIEMPRE |
| Justicia gratuita | Si el cliente la tiene reconocida o en trámite | Cuando aplique |
| Medidas cautelares | Embargo preventivo, anotación demanda, etc. | Cuando proceda |
| Designación de dirección electrónica | LexNET | SIEMPRE |
| Petición de copia testimoniada | Si se quiere conservar copia con sello del tribunal | Opcional |
| Subsanación de defectos formales (art. 231 LEC) | Anticipar que se subsanará cualquier defecto | Útil cuando se anticipa controversia |
| Intereses procesales del art. 576 LEC | Reforzar petición de intereses | Cuando hay condena dineraria |

### Estructura formal del otrosí

```
OTROSÍ PRIMERO DIGO: Que esta parte fija expresamente la cuantía del presente 
procedimiento en [IMPORTE] euros, correspondiendo en consecuencia el trámite 
del juicio [verbal/ordinario], conforme a los artículos 248 y siguientes LEC.

SUPLICO AL TRIBUNAL DE INSTANCIA tenga por hecha la anterior manifestación a 
los efectos legales oportunos.
```

## 4. Estructura tripartita de los HECHOS (estilo Carlos)

Carlos piensa en bloques de tres. La narración de los hechos se beneficia de esa estructura:

1. **Origen de la relación jurídica**: cuándo y cómo nació (contrato, hecho jurídico, acto).
2. **Desarrollo y cumplimiento del actor**: qué hizo el cliente conforme a lo pactado.
3. **Incumplimiento o controversia**: qué dejó de hacer el demandado, cuándo, con qué consecuencias.

A estos tres bloques se añaden:

4. **Reclamación extrajudicial**: qué se intentó antes de demandar (MASC).
5. **Cuantificación**: importe líquido o liquidable, con desglose.

Y en demandas con pluralidad de hechos, se numeran correlativamente con el verbo en presente histórico (*"PRIMERO.- Mediante contrato de fecha…"*).

## 5. Subsunción real entre hechos y derecho

Cada FUNDAMENTO DE DERECHO sustantivo debe terminar con un **párrafo de subsunción** que conecta la doctrina con los hechos:

```
[…] La STS de la Sala Primera nº 658/2019, de 5 de diciembre [ECLI:ES:TS:2019:3920], 
declara que «[cita literal corta]».

Aplicada esta doctrina al supuesto de autos: el contrato suscrito entre las partes 
en fecha 12-03-2024 (Doc. 1) reúne los tres requisitos exigidos por el Tribunal 
Supremo, a saber: (i) [hecho 1], (ii) [hecho 2] y (iii) [hecho 3]. De ahí que la 
consecuencia jurídica que el Alto Tribunal anuda a tales hechos —[consecuencia]— 
deba aplicarse al presente procedimiento.
```

Sin ese párrafo, la cita es decorativa. Con él, es argumento.

## 6. Riesgos a anticipar

Antes de redactar, anotar los riesgos típicos:

- **Defecto en el modo de proponer la demanda** (art. 416.1.5 LEC) → cuidar redacción del suplico.
- **Falta de litisconsorcio** → identificar a todos los demandados necesarios.
- **Cosa juzgada / litispendencia** → comprobar.
- **Inadecuación de procedimiento** → fijar cuantía y procedimiento en otrosí.
- **Falta de capacidad o representación** → poder, escritura societaria, certificación.

Si aparece riesgo, blindarlo en el escrito (otrosí de subsanación, fundamento específico, etc.).

## 7. Confirmación con Carlos

Antes de pasar a la Fase 4, devolver a Carlos un **plan estratégico** breve:

```
PLAN ESTRATÉGICO — Reclamación cantidad ABC ↔ XYZ

PRETENSIÓN PRINCIPAL: condena al pago de 12.450 € + intereses 1108 CC + costas.
PRETENSIÓN SUBSIDIARIA: no procede (caso claro).

PRUEBA: documental (Doc. 1-7), interrogatorio del legal representante de XYZ.
NO se solicita pericial.

OTROSÍES PROPUESTOS:
   1. Cuantía y procedimiento (verbal con postulación).
   2. Anuncio de prueba (art. 265.1).
   3. Designación dirección LexNET.

RIESGO DETECTADO: ninguno significativo.
PRÓXIMO PASO: jurisprudencia STS (5 mínimo, vía vLex).

¿Apruebas el plan?
```
