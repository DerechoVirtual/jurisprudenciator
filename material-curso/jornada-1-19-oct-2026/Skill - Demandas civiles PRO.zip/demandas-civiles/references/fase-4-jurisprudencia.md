# FASE 4 — Jurisprudencia: cómo invocar vLex/CENDOJ y formatear las citas

> **Regla cardinal**: cero invención. Cualquier sentencia que aparezca en la demanda tiene que existir realmente, con su ECLI verificado en vLex (preferente) o CENDOJ. Si no se encuentra tras dos intentos razonables, se elimina y se busca otra.

## 1. Mínimo y formato

- **Mínimo 5 STS** aplicables al caso. Si no hay 5, parar y consultar a Carlos.
- Cada sentencia se cita con: órgano, sala, fecha, nº de recurso, ponente, ECLI completo.
- Cita literal corta entre comillas (15-35 palabras), tomada del fundamento jurídico real.
- Inmediatamente después, párrafo de **subsunción** al caso concreto (ver `fase-3-estrategia.md`).

## 2. Cómo invocar vLex (preferente)

Llamar a la skill `vlex-jurisprudencia` con la consulta caracterizada:

- **Órgano**: Tribunal Supremo, Sala Primera (Civil).
- **Materia**: vocabulario técnico exacto, no coloquial. Ej.: "intereses moratorios operaciones comerciales" en lugar de "intereses por retraso".
- **Rango temporal**: últimos 10 años por defecto, salvo doctrina histórica relevante.
- **Producto**: 5 leading cases con ECLI, ratio decidendi, cita literal y aplicación al caso.

Ejemplo de invocación:

```
Necesito 5 STS Sala Primera del TS sobre [materia exacta] para fundamentar 
[tipo de demanda]. Caracterización:
- Órgano: Tribunal Supremo, Sala Primera (Civil).
- Materia: [keywords técnicos].
- Rango: 2018-2025.
- Producto: 5 leading cases con ECLI verificado, ratio en 1-2 frases, 
  cita literal corta (15-35 palabras), aplicación al caso de [breve descripción].

Hechos del caso a los que se aplicará la doctrina:
[3-5 frases sobre el caso concreto].
```

vLex devolverá, en formato listo para pegar:

```
1. STS Sala Primera nº 658/2019, de 5 de diciembre [ECLI:ES:TS:2019:3920]
   Ponente: [nombre]
   Ratio: [1-2 frases].
   Cita literal: «[15-35 palabras del FJ X]»
   Aplicación al caso: [conexión con los hechos].
```

## 3. Cómo invocar CENDOJ (alternativa)

Llamar a la skill `cendoj-jurisprudencia`. Mismo formato de petición y de devolución. CENDOJ es la base oficial del CGPJ; útil para verificación cruzada de ECLI.

## 4. Distribución de las STS por fundamento

Cada Fundamento de Derecho sustantivo debería sostenerse en al menos:

- **Una STS principal** (la que mejor encaja con los hechos).
- **Una STS de refuerzo** (consolidación doctrinal).

Para una demanda con 3 fundamentos sustantivos (legitimación, fondo, intereses/costas), la distribución típica es:

| Fundamento | STS principal | STS de refuerzo |
| --- | --- | --- |
| Legitimación | 1 STS | 1 STS |
| Fondo del asunto | 1 STS | 1-2 STS |
| Intereses / costas | 1 STS | (opcional) |

Total: 5-6 STS bien distribuidas.

## 5. Anti-cita suelta

**Prohibido**:

- Citar una STS y pasar al siguiente FJ sin más.
- Reproducir un fragmento extenso sin párrafo de aplicación al caso.
- Citar dos sentencias seguidas sin diferenciar qué aporta cada una.

**Obligatorio**:

- Tras cada cita, párrafo de subsunción (ver `fase-3-estrategia.md` apartado 5).
- Si se citan dos STS sobre el mismo punto, decir qué añade la segunda (consolidación, matiz, evolución).

## 6. Verificación final

Antes de cerrar el escrito, invocar `verificacion-ecli-skill` para auditar cada ECLI. Si una falla:

- Eliminarla del escrito.
- Sustituirla por otra del mismo bloque doctrinal (volver a vLex).
- No entregar la demanda con ECLI no verificado.

## 7. Sentencias de la Audiencia Provincial

Opcionales, salvo que:

- Carlos lo pida expresamente.
- La doctrina del TS no sea unánime y convenga mostrar la línea de la AP que conocería del eventual recurso de apelación.
- Sea propiedad horizontal o materias muy locales donde la AP marca matices.

Si se incluyen, mismas reglas: ECLI verificado, ratio, cita literal, aplicación al caso.

## 8. Doctrina del TC y normativa europea

- **TC**: cuando haya derecho fundamental en juego (art. 24 CE, igualdad, intimidad, etc.).
- **TJUE**: cuando se invoque normativa europea (cláusulas abusivas con la Directiva 93/13, consumidores, protección de datos, etc.). Las sentencias TJUE valen tanto como las del TS y a menudo más.
- **TEDH**: en derechos fundamentales del Convenio Europeo.

Cita: órgano + asunto + fecha + ECLI/identificador.

## 9. Output esperado de esta fase

Devolver a Carlos un **bloque jurisprudencial** listo para insertar en los Fundamentos de Derecho:

```
JURISPRUDENCIA PARA INSERTAR EN FD VI (FONDO DEL ASUNTO):

1. STS Sala Primera nº 658/2019, de 5 de diciembre [ECLI:ES:TS:2019:3920]
   Ponente: D. [nombre]
   Ratio: [1-2 frases].
   Cita: «[FJ X — 25 palabras]»
   Subsunción al caso: el contrato de autos reúne los requisitos exigidos por 
   esta doctrina porque (i) [hecho], (ii) [hecho], (iii) [hecho].

2. STS Sala Primera nº [X]/2022 […]
   [...]

[5 STS en total]
```

Con esto, la Fase 5 (redacción) consiste en integrar este bloque en los FD correspondientes.
