# Plantilla Word — Formato profesional Derecho Virtual

> **Regla**: este archivo describe el formato exacto al que debe ajustarse el `.docx` final. El script `scripts/generar_demanda_word.py` lo aplica automáticamente; si se usa otra vía, replicarlo manualmente.

## 1. Configuración de página

- Tamaño: A4 (210 × 297 mm).
- Márgenes:
  - Superior: 2,5 cm.
  - Inferior: 2,5 cm.
  - Izquierdo: 3,0 cm (para encuadernación).
  - Derecho: 2,5 cm.
- Orientación: vertical.
- Numeración de páginas: pie de página, centrado, formato "Página X de Y".

## 2. Tipografía

- Fuente principal: **Times New Roman**.
- Tamaño cuerpo: **12 pt**.
- Interlineado: **1,15**.
- Espaciado posterior: 6 pt entre párrafos.
- Justificación: completa.
- Sangría primera línea: 0 cm (no se sangra; se separa con espaciado posterior).

## 3. Estilos por elemento

### Encabezamiento del tribunal

```
Estilo: Centrado, mayúsculas, negrita, 14 pt.
Posición: Primera línea del documento.
Espaciado posterior: 24 pt (espacio doble antes de la comparecencia).
```

Ejemplo:

> **AL TRIBUNAL DE INSTANCIA DE MADRID**
> **SECCIÓN CIVIL**

### Comparecencia

```
Estilo: Justificado, 12 pt, sin negrita salvo nombres de partes.
Espaciado posterior: 12 pt.
```

### Títulos de sección (HECHOS, FUNDAMENTOS DE DERECHO, SUPLICO)

```
Estilo: Centrado, mayúsculas, negrita, 13 pt, espaciado entre letras: 2 pt.
Espaciado anterior: 18 pt.
Espaciado posterior: 12 pt.
```

Ejemplo:

> **H E C H O S**

### Numeración de hechos y fundamentos

```
Estilo: Negrita el ordinal y el guion separador; texto en redonda.
Indentación: 0 cm.
```

Ejemplo:

> **PRIMERO.-** Mediante contrato de fecha 12 de marzo de 2024, mi mandante [...]

### Citas jurisprudenciales

```
Estilo del ECLI: negrita, entre corchetes.
Estilo de la cita literal: redonda, entre comillas latinas «...».
```

Ejemplo:

> La STS de la Sala Primera nº 658/2019, de 5 de diciembre **[ECLI:ES:TS:2019:3920]**, declara que «la indemnización debe responder al daño efectivamente acreditado».

### Suplico

```
Estilo del verbo rector: mayúsculas, negrita.
Peticiones numeradas con ordinal escrito en negrita.
Subapartados con letras minúsculas seguidas de paréntesis: a) b) c).
```

### Otrosíes

```
Estilo del título: mayúsculas, negrita, formato "OTROSÍ [ORDINAL] DIGO:".
Cada otrosí termina con su propio SUPLICO breve (mayúsculas, negrita).
```

### Pie de firma

```
Estructura: dos columnas, separación 3 cm.
Columna izquierda: Letrado.
Columna derecha: Procurador.
Estilo: centrado dentro de la columna, "Fdo.: [Nombre]" en redonda y nº de colegiado en línea inferior.
Espaciado anterior: 36 pt (para dejar hueco a la firma manuscrita).
```

### Documentos acompañados

```
Estilo: lista numerada con "Doc. [N].- ", justificada.
Espaciado posterior: 24 pt antes de los documentos.
```

## 4. Marca y branding

- **Sin** logo del despacho en el cuerpo del escrito (se añade en membrete cuando se imprima, no en el `.docx` para LexNET).
- Encabezado de página opcional con "DEMANDA — [PARTE ACTORA] / [PARTE DEMANDADA]" en 9 pt, alineación derecha.
- Pie de página con numeración de página y nombre corto del documento, 9 pt.

## 5. Errores frecuentes a evitar

- ❌ Calibri o Arial → usar Times New Roman.
- ❌ Interlineado 1,5 o doble → usar 1,15 (estándar forense).
- ❌ Sangría con tabulador al inicio de párrafo → usar espaciado posterior, no sangría.
- ❌ Numeración árabe en hechos (1.- 2.- 3.-) → usar ordinal escrito en mayúsculas.
- ❌ Comillas inglesas ("...") → usar comillas latinas («...»).
- ❌ Negritas excesivas → solo en partes, importes, fechas críticas, ECLI y verbos rectores.
- ❌ Pie de firma a una sola columna → siempre dos cuando haya procurador.

## 6. Checklist de formato antes de cerrar el Word

- [ ] Tipografía Times New Roman 12 pt en todo el cuerpo.
- [ ] Interlineado 1,15.
- [ ] Márgenes 3/2,5/2,5/2,5 cm.
- [ ] Encabezamiento del tribunal centrado y en negrita.
- [ ] Títulos de sección centrados, en mayúsculas y con espaciado entre letras.
- [ ] Numeración de hechos en ordinal escrito (PRIMERO, SEGUNDO…).
- [ ] Citas jurisprudenciales con ECLI en negrita y citas en comillas latinas.
- [ ] Suplico con verbos rectores en mayúsculas y negrita.
- [ ] Pie de firma a dos columnas.
- [ ] Lista de documentos numerada al final.
- [ ] Pie de página con "Página X de Y".
- [ ] Numeración de páginas correcta.
