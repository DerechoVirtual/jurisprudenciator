#!/usr/bin/env python3
"""
generar_demanda_word.py
=======================

Genera una demanda civil/mercantil/familia en formato Word (.docx) perfectamente
maquetada, con todos los criterios de formato profesional aplicados:

- Times New Roman 12 pt, interlineado 1,15.
- Márgenes 3/2,5/2,5/2,5 cm.
- Títulos de sección centrados, en mayúsculas y negrita, con espaciado entre letras.
- Numeración ordinal escrita (PRIMERO, SEGUNDO, TERCERO...).
- ECLI en negrita entre corchetes.
- Citas literales con comillas latinas.
- Pie de firma a dos columnas (letrado y procurador).
- Numeración de páginas.

Uso
---
python3 generar_demanda_word.py --json caso.json --output demanda.docx

El JSON de entrada debe seguir la estructura mostrada en `EJEMPLO_JSON` al final.
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

try:
    from docx import Document
    from docx.enum.section import WD_ORIENT
    from docx.enum.table import WD_ALIGN_VERTICAL
    from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_LINE_SPACING
    from docx.oxml.ns import qn
    from docx.oxml import OxmlElement
    from docx.shared import Cm, Pt, RGBColor
except ImportError:
    print("ERROR: falta python-docx. Instala con: pip install python-docx --break-system-packages", file=sys.stderr)
    sys.exit(1)


# ----------------------- Helpers de formato -----------------------

def configurar_pagina(doc: Document) -> None:
    """A4 vertical con márgenes 3/2,5/2,5/2,5 cm."""
    for section in doc.sections:
        section.orientation = WD_ORIENT.PORTRAIT
        section.page_width = Cm(21)
        section.page_height = Cm(29.7)
        section.left_margin = Cm(3)
        section.right_margin = Cm(2.5)
        section.top_margin = Cm(2.5)
        section.bottom_margin = Cm(2.5)


def configurar_estilo_normal(doc: Document) -> None:
    """Times New Roman 12 pt, interlineado 1,15, justificado."""
    style = doc.styles["Normal"]
    font = style.font
    font.name = "Times New Roman"
    font.size = Pt(12)

    # Forzar fuente para alfabetos no latinos también
    rpr = style.element.get_or_add_rPr()
    rfonts = rpr.find(qn("w:rFonts"))
    if rfonts is None:
        rfonts = OxmlElement("w:rFonts")
        rpr.append(rfonts)
    for attr in ("w:ascii", "w:hAnsi", "w:cs", "w:eastAsia"):
        rfonts.set(qn(attr), "Times New Roman")

    pf = style.paragraph_format
    pf.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
    pf.line_spacing_rule = WD_LINE_SPACING.MULTIPLE
    pf.line_spacing = 1.15
    pf.space_after = Pt(6)
    pf.space_before = Pt(0)


def add_numeracion_paginas(doc: Document) -> None:
    """Numeración 'Página X de Y' en pie de página, centrado, 9 pt."""
    for section in doc.sections:
        footer = section.footer
        p = footer.paragraphs[0]
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        run = p.add_run("Página ")
        run.font.size = Pt(9)
        # Campo PAGE
        fldChar1 = OxmlElement("w:fldChar")
        fldChar1.set(qn("w:fldCharType"), "begin")
        instrText = OxmlElement("w:instrText")
        instrText.text = "PAGE"
        fldChar2 = OxmlElement("w:fldChar")
        fldChar2.set(qn("w:fldCharType"), "end")
        run._r.append(fldChar1)
        run._r.append(instrText)
        run._r.append(fldChar2)
        run2 = p.add_run(" de ")
        run2.font.size = Pt(9)
        run3 = p.add_run()
        run3.font.size = Pt(9)
        # Campo NUMPAGES
        fldChar3 = OxmlElement("w:fldChar")
        fldChar3.set(qn("w:fldCharType"), "begin")
        instrText2 = OxmlElement("w:instrText")
        instrText2.text = "NUMPAGES"
        fldChar4 = OxmlElement("w:fldChar")
        fldChar4.set(qn("w:fldCharType"), "end")
        run3._r.append(fldChar3)
        run3._r.append(instrText2)
        run3._r.append(fldChar4)


def add_encabezamiento_tribunal(doc: Document, tribunal: str, seccion: str) -> None:
    """Encabezamiento centrado, mayúsculas, negrita, 14 pt."""
    for texto in (f"AL TRIBUNAL DE INSTANCIA DE {tribunal.upper()}", f"SECCIÓN {seccion.upper()}"):
        p = doc.add_paragraph()
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        p.paragraph_format.space_after = Pt(6)
        run = p.add_run(texto)
        run.bold = True
        run.font.size = Pt(14)
    # Espacio doble tras encabezamiento
    doc.add_paragraph().paragraph_format.space_after = Pt(18)


def add_titulo_seccion(doc: Document, texto: str) -> None:
    """Título de sección: centrado, mayúsculas, negrita, 13 pt, con espaciado entre letras."""
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.space_before = Pt(18)
    p.paragraph_format.space_after = Pt(12)
    # Espaciado entre letras: separar con espacios para simular tracking
    espaciado = "    ".join(list(texto.upper()))
    run = p.add_run(espaciado)
    run.bold = True
    run.font.size = Pt(13)


def add_parrafo_numerado(doc: Document, ordinal: str, texto: str) -> None:
    """Párrafo con ordinal en negrita y texto en redonda."""
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
    run_ord = p.add_run(f"{ordinal}.- ")
    run_ord.bold = True
    p.add_run(texto)


def add_parrafo_simple(doc: Document, texto: str, *, justify: bool = True, bold: bool = False) -> None:
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY if justify else WD_ALIGN_PARAGRAPH.LEFT
    run = p.add_run(texto)
    run.bold = bold


def add_pie_firma(doc: Document, letrado: str, colegio_letrado: str,
                  procurador: str | None, colegio_procurador: str | None) -> None:
    """Pie de firma a dos columnas (letrado izquierda, procurador derecha)."""
    doc.add_paragraph().paragraph_format.space_after = Pt(36)  # hueco para firma manuscrita
    if procurador:
        table = doc.add_table(rows=2, cols=2)
        table.autofit = True
        # Fila 1: nombres
        c1 = table.cell(0, 0)
        c2 = table.cell(0, 1)
        for cell in (c1, c2):
            cell.vertical_alignment = WD_ALIGN_VERTICAL.CENTER
        p1 = c1.paragraphs[0]
        p1.alignment = WD_ALIGN_PARAGRAPH.CENTER
        run1 = p1.add_run(f"Fdo.: {letrado}")
        run1.bold = True
        p2 = c2.paragraphs[0]
        p2.alignment = WD_ALIGN_PARAGRAPH.CENTER
        run2 = p2.add_run(f"Fdo.: {procurador}")
        run2.bold = True
        # Fila 2: colegios
        c3 = table.cell(1, 0)
        c4 = table.cell(1, 1)
        p3 = c3.paragraphs[0]
        p3.alignment = WD_ALIGN_PARAGRAPH.CENTER
        p3.add_run(f"Abogado ICAM nº {colegio_letrado}")
        p4 = c4.paragraphs[0]
        p4.alignment = WD_ALIGN_PARAGRAPH.CENTER
        p4.add_run(f"Procurador Col. nº {colegio_procurador}")
    else:
        # Solo letrado, centrado
        p = doc.add_paragraph()
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        run = p.add_run(f"Fdo.: {letrado}")
        run.bold = True
        p2 = doc.add_paragraph()
        p2.alignment = WD_ALIGN_PARAGRAPH.CENTER
        p2.add_run(f"Abogado ICAM nº {colegio_letrado}")


# ----------------------- Generador principal -----------------------

ORDINALES = [
    "PRIMERO", "SEGUNDO", "TERCERO", "CUARTO", "QUINTO",
    "SEXTO", "SÉPTIMO", "OCTAVO", "NOVENO", "DÉCIMO",
    "UNDÉCIMO", "DUODÉCIMO", "DECIMOTERCERO", "DECIMOCUARTO", "DECIMOQUINTO",
]
ROMANOS = ["I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX", "X", "XI", "XII"]


def generar_demanda(caso: dict, output: Path) -> None:
    doc = Document()
    configurar_pagina(doc)
    configurar_estilo_normal(doc)
    add_numeracion_paginas(doc)

    # 1. Encabezamiento
    tribunal = caso.get("tribunal", {})
    add_encabezamiento_tribunal(doc, tribunal.get("localidad", "[LOCALIDAD]"),
                                 tribunal.get("seccion", "Civil"))

    # 2. Comparecencia
    add_parrafo_simple(doc, caso.get("comparecencia", "[Comparecencia]"))

    # 3. Fórmula procesal
    add_parrafo_simple(doc, caso.get("formula_procesal", "[Fórmula procesal]"))

    # 4. HECHOS
    add_titulo_seccion(doc, "Hechos")
    for i, hecho in enumerate(caso.get("hechos", []), start=1):
        ordinal = ORDINALES[i - 1] if i <= len(ORDINALES) else f"{i}º"
        add_parrafo_numerado(doc, ordinal, hecho)

    # 5. FUNDAMENTOS DE DERECHO
    add_parrafo_simple(doc, "A los anteriores hechos resultan de aplicación los siguientes:")
    add_titulo_seccion(doc, "Fundamentos de Derecho")
    for i, fd in enumerate(caso.get("fundamentos", []), start=1):
        romano = ROMANOS[i - 1] if i <= len(ROMANOS) else str(i)
        # Título FD
        p = doc.add_paragraph()
        run = p.add_run(f"{romano}.- {fd.get('titulo', '').upper()}.")
        run.bold = True
        # Cuerpo
        for parrafo in fd.get("cuerpo", []):
            add_parrafo_simple(doc, parrafo)

    # 6. SUPLICO
    add_titulo_seccion(doc, "Suplico")
    suplico = caso.get("suplico", {})
    add_parrafo_simple(doc, suplico.get("encabezado", ""))
    for i, peticion in enumerate(suplico.get("peticiones", []), start=1):
        ordinal = ORDINALES[i - 1] if i <= len(ORDINALES) else f"{i}º"
        add_parrafo_numerado(doc, ordinal, peticion)
    if suplico.get("cierre"):
        add_parrafo_simple(doc, suplico["cierre"])

    # 7. OTROSÍES
    for i, otrosi in enumerate(caso.get("otrosies", []), start=1):
        ordinal = ORDINALES[i - 1] if i <= len(ORDINALES) else f"{i}º"
        p = doc.add_paragraph()
        run = p.add_run(f"OTROSÍ {ordinal} DIGO: ")
        run.bold = True
        p.add_run(otrosi.get("texto", ""))
        if otrosi.get("suplico"):
            p2 = doc.add_paragraph()
            run2 = p2.add_run("SUPLICO AL TRIBUNAL DE INSTANCIA")
            run2.bold = True
            p2.add_run(f" {otrosi['suplico']}")

    # 8. Cierre
    cierre = caso.get("cierre", "")
    if cierre:
        add_parrafo_simple(doc, cierre)

    # 9. Firmas
    firma = caso.get("firma", {})
    add_pie_firma(
        doc,
        letrado=firma.get("letrado", "[LETRADO]"),
        colegio_letrado=firma.get("colegio_letrado", "[X]"),
        procurador=firma.get("procurador"),
        colegio_procurador=firma.get("colegio_procurador"),
    )

    # 10. Documentos
    documentos = caso.get("documentos", [])
    if documentos:
        doc.add_paragraph().paragraph_format.space_after = Pt(18)
        add_parrafo_simple(doc, "Se acompañan los siguientes documentos:", bold=True)
        for i, descripcion in enumerate(documentos, start=1):
            p = doc.add_paragraph()
            run = p.add_run(f"Doc. {i}.- ")
            run.bold = True
            p.add_run(descripcion)

    doc.save(output)
    print(f"OK — demanda guardada en: {output}")


def main() -> None:
    parser = argparse.ArgumentParser(description="Generador de demandas civiles en Word.")
    parser.add_argument("--json", required=True, help="Ruta al JSON con los datos de la demanda.")
    parser.add_argument("--output", required=True, help="Ruta del .docx de salida.")
    args = parser.parse_args()

    json_path = Path(args.json)
    output_path = Path(args.output)
    if not json_path.exists():
        print(f"ERROR: no existe {json_path}", file=sys.stderr)
        sys.exit(1)

    with json_path.open("r", encoding="utf-8") as f:
        caso = json.load(f)

    generar_demanda(caso, output_path)


# ----------------------- Ejemplo de JSON -----------------------

EJEMPLO_JSON = """
{
  "tribunal": {
    "localidad": "Madrid",
    "seccion": "Civil"
  },
  "comparecencia": "D. Juan Sánchez, Procurador de los Tribunales (Col. nº 4321), en nombre y representación de D. Juan Pérez García, según acredito mediante poder que se acompaña como Documento nº 1, bajo la dirección letrada de D. Carlos Rivero, abogado del ICAM nº 67890, con despacho profesional en C/ Ejemplo 1, Madrid, y dirección electrónica para notificaciones [correo para notificaciones], ante el Tribunal comparezco y como mejor proceda en Derecho, DIGO:",
  "formula_procesal": "Que mediante el presente escrito vengo a INTERPONER DEMANDA DE JUICIO VERBAL frente a Construcciones SL, con CIF B-87654321 y domicilio en C/ Demandado 5, Madrid, en virtud de los siguientes:",
  "hechos": [
    "Mediante contrato de suministro de fecha 12 de marzo de 2024 (Doc. 2), las partes acordaron...",
    "Mi mandante cumplió íntegramente sus obligaciones, según se acredita en los albaranes (Doc. 3)...",
    "La demandada no abonó las facturas nº 240/24, 241/24 y 245/24 (Doc. 4-6) por importe total de 12.450 €...",
    "CUMPLIMIENTO DEL MASC (ART. 5 LO 1/2025): En fecha 12-02-2026 se remitió burofax con acuse y certificación (Doc. 7) sin obtener respuesta tras 30 días...",
    "El importe principal reclamado asciende a 12.450 €, devengando intereses legales desde el primer vencimiento."
  ],
  "fundamentos": [
    {
      "titulo": "Competencia objetiva y territorial",
      "cuerpo": [
        "Es competente el Tribunal de Instancia de Madrid, Sección Civil, en aplicación del art. 50 LEC...",
        "El demandado tiene su domicilio social en Madrid, según se acredita en la nota simple del Registro Mercantil (Doc. 8)."
      ]
    },
    {
      "titulo": "Cumplimiento del MASC (art. 5 LO 1/2025)",
      "cuerpo": [
        "Mi mandante ha dado cumplimiento al requisito de procedibilidad mediante burofax con acuse de recibo y certificación de contenido remitido en fecha 12-02-2026..."
      ]
    }
  ],
  "suplico": {
    "encabezado": "SUPLICO AL TRIBUNAL DE INSTANCIA: que tenga por presentada esta demanda y los documentos que la acompañan, se sirva admitirla, dándole el trámite del juicio verbal, y previos los trámites legales, dicte sentencia por la que:",
    "peticiones": [
      "Estime íntegramente la presente demanda.",
      "Condene a la parte demandada a abonar a mi mandante: a) la cantidad de 12.450 € en concepto de principal; b) los intereses legales del art. 1108 CC desde 01-01-2026 hasta su completo pago; c) las costas procesales del presente procedimiento."
    ],
    "cierre": "Es justicia que se pide en Madrid, a 11 de mayo de 2026."
  },
  "otrosies": [
    {
      "texto": "Que esta parte fija expresamente la cuantía del presente procedimiento en 12.450 € (DOCE MIL CUATROCIENTOS CINCUENTA EUROS), correspondiendo el trámite del juicio verbal con postulación preceptiva, conforme a los artículos 248 y siguientes LEC.",
      "suplico": "tenga por hecha la anterior manifestación a los efectos legales oportunos."
    },
    {
      "texto": "Que esta parte se valdrá de los siguientes medios de prueba: a) documental (Doc. 1 a 8); b) interrogatorio del legal representante de la demandada.",
      "suplico": "tenga por anunciada la anterior prueba a los efectos del art. 265.1 LEC."
    }
  ],
  "firma": {
    "letrado": "Carlos Rivero",
    "colegio_letrado": "67890",
    "procurador": "Juan Sánchez",
    "colegio_procurador": "4321"
  },
  "documentos": [
    "Poder general para pleitos.",
    "Contrato de suministro de 12-03-2024.",
    "Albaranes de entrega.",
    "Factura nº 240/24.",
    "Factura nº 241/24.",
    "Factura nº 245/24.",
    "Burofax MASC con acuse de recibo y certificación de contenido.",
    "Nota simple Registro Mercantil de Construcciones SL."
  ]
}
"""


if __name__ == "__main__":
    main()
