---
name: demandas-civiles
description: >-
  Redacción EXHAUSTIVA de demandas civiles, mercantiles y de familia conforme a
  la LEC y a la LO 1/2025. Activar cuando Carlos pida redactar, preparar o
  interponer cualquier demanda, monitorio, juicio ordinario, verbal, desahucio,
  reclamación de cantidad, ejecución, divorcio contencioso, propiedad
  horizontal, arrendamientos, mercantil, cláusulas abusivas o consumidores. NO
  redacta al primer disparo: obliga a 5 fases (documentación, batería de
  preguntas con AskUserQuestion, viabilidad y MASC, estrategia, jurisprudencia
  con mínimo 5 STS verificadas en vLex/CENDOJ con ECLI). Encadena
  vlex-jurisprudencia, estilo-carlos-escritos-judiciales, subsuncion-juridica,
  verificacion-ecli y docx. Entrega SIEMPRE en Word .docx maquetado listo para
  LexNET. Prohibido inventar jurisprudencia, omitir el MASC o entregar texto
  plano. Prevalece sobre otras skills de demandas cuando Carlos quiera la
  versión extensa, profunda y exhaustiva.
license: Proprietary - Carlos Rivero / Derecho Virtual
---

# Demandas Civiles PRO — Civil, Mercantil y Familia ante el Tribunal de Instancia

> **Propósito**: redactar demandas civiles, mercantiles y de familia del más alto nivel forense, plenamente conformes a la LEC vigente y a la LO 1/2025, con MASC correctamente acreditado, mínimo 5 STS verificadas en vLex/CENDOJ con ECLI, subsunción real entre hechos y doctrina, y entrega final en Word `.docx` perfectamente maquetado y listo para presentar ante el Tribunal de Instancia competente vía LexNET.

---

## Reglas cardinales (no negociables)

1. **Nunca redactar al primer disparo.** Antes de escribir una sola línea de la demanda hay que completar las cinco fases descritas más abajo. Si Carlos insiste en saltarse fases, recordarle que la calidad y la admisibilidad del escrito dependen de ello, y solo si insiste explícitamente, ofrecer una versión exprés diferenciada — pero proponiendo siempre primero la vía completa.

2. **Mínimo cinco (5) Sentencias del Tribunal Supremo aplicables y verificadas con ECLI**. Cero invención. La verificación se delega siempre en la skill `vlex-jurisprudencia` (preferente, según preferencia de Carlos) y, en su defecto, en `cendoj-jurisprudencia`. Si tras búsqueda razonable no aparecen 5 STS aplicables, hay que decírselo a Carlos antes de seguir y consensuar alternativa (más SAP, doctrina del TC, normativa europea, etc.).

3. **MASC siempre acreditado.** Toda demanda debe incluir un HECHO específico de cumplimiento del requisito de procedibilidad del art. 5 LO 1/2025, con su correspondiente Documento del art. 264.4 LEC, salvo que el procedimiento se encuentre en alguna de las excepciones tasadas (ver `references/excepciones.md`). Si el caso encaja en una excepción, justificarla expresamente.

4. **Tribunal de Instancia (no "Juzgado").** Toda demanda se dirige al Tribunal de Instancia competente, con su sección (Civil, Familia, Mercantil) y la denominación oficial introducida por la LO 1/2025. Cero anacronismos.

5. **Entrega final en Word `.docx` perfectamente maquetado**. Nunca texto plano, nunca Markdown, nunca "te paso el contenido por chat". El archivo debe quedar listo para que Carlos lo firme y lo presente vía LexNET. Para generar el Word se delega siempre en la skill `docx` (con apoyo de `formato-escritos-judiciales`) o, preferentemente, en el script `scripts/generar_demanda_word.py` que está incluido en este paquete y aplica directamente todos los criterios de formato (tipografía, márgenes, encabezamientos, numeración ordinal, pie de firma).

6. **Estilo Carlos obligatorio en la pasada final.** Antes de entregar, pasar el escrito por la skill `estilo-carlos-escritos-judiciales` para imprimir su pluma (estructura tripartita, contraste "una cosa es X / otra Y", explicación del por qué antes del qué, cierre estratégico, cero adjetivos vacíos). El escrito no debe sonar a IA genérica.

7. **En caso de duda — preguntar, no inventar.** Mejor ocho baterías de preguntas con respuestas reales que una demanda brillante con datos inventados que se caiga al primer cotejo con el expediente.

---

## Workflow — Las 5 fases obligatorias

### FASE 0 — Recopilación documental

Pedir a Carlos toda la documentación necesaria. **No avanzar a la Fase 1 hasta confirmar qué hay y qué no hay.** Lectura obligatoria de `references/fase-0-recopilacion-documentos.md`.

Mínimo imprescindible según el tipo de demanda:
- **Reclamación de cantidad / monitorio / verbal**: contrato, factura(s), albaranes, justificantes de pago parciales, burofax MASC, cualquier reconocimiento de deuda.
- **Desahucio**: contrato de arrendamiento, requerimientos previos, certificado de deuda, comunicaciones con el arrendatario.
- **Familia**: certificado de matrimonio, libro de familia, certificados de nacimiento, pruebas de ingresos de ambos cónyuges, pruebas patrimoniales, propuesta de convenio (si la hay).
- **Mercantil / responsabilidad civil**: contrato, informe pericial, comunicaciones, atestado o informe técnico, seguros.
- **Propiedad horizontal**: certificación de la deuda, acta de la junta, notificación al deudor, estatutos (si discutidos).
- **MASC**: prueba documental del intento de negociación previa (burofax con acuse, acta de mediación, certificación del tercero, declaración responsable si domicilio desconocido).

Si falta documentación crítica, dejar esos puntos como "[PENDIENTE — Carlos enviará]" y avanzar igualmente, **pero sin redactar la demanda final** hasta cerrarlos.

### FASE 1 — Batería estructurada de preguntas

Lectura obligatoria de `references/fase-1-bateria-preguntas.md`. Usar siempre `AskUserQuestion` para preguntas con opciones cerradas; texto libre solo cuando tenga sentido (DNI, nombres, fechas, números, importes).

Las baterías se ejecutan **en orden** y no se avanza a la siguiente sin tener la respuesta de la actual:

1. **Posición y tipo de demanda**: ¿quién demanda a quién?, ¿qué se pide?, ¿qué procedimiento corresponde por cuantía y materia?
2. **Datos identificativos**: actor, demandado, letrado, procurador, Tribunal de Instancia competente, sección, justicia gratuita.
3. **MASC** (siempre, salvo excepción): ¿ya se hizo?, ¿con qué medio?, ¿qué documento se aporta?, ¿hay declaración responsable?
4. **Hechos y prueba**: cronología del conflicto, documentos disponibles, testigos, pericial.
5. **Pretensión y suplico**: importe líquido o liquidable, intereses, costas, condena en costas por temeridad si procede.
6. **Otrosíes**: cuantía, prueba que se propondrá, medidas cautelares, justicia gratuita, traslado de copias.
7. **Jurisprudencia y formato final**: ¿con jurisprudencia STS verificada en vLex o sin ella?, ¿extensión deseada en palabras?, ¿plantilla de despacho?

> Si Carlos da poca información inicial, **no rellenar con "ejemplo"**. Preguntar.
> Si Carlos dice "redacta ya", recordar la regla cardinal y proponer la versión exprés diferenciada.

### FASE 2 — Análisis de viabilidad, competencia y MASC

Lectura obligatoria de `references/fase-2-viabilidad-procedimiento.md`, `references/procedimientos.md` y `references/excepciones.md`. Antes de redactar nada:

1. **Procedimiento adecuado por cuantía y materia** (arts. 248-250 LEC):
   - ≤ 2.000 € → verbal sin postulación preceptiva.
   - 2.001 € – 15.000 € → verbal con postulación preceptiva.
   - > 15.000 € → ordinario.
   - Indeterminada → según materia.
   - Materias del art. 250 LEC → verbal por razón de la materia (arrendamientos, posesión, alimentos, etc.) cualquiera que sea la cuantía.
   - Monitorio → deuda dineraria, vencida, exigible, ≤ 250.000 €.

2. **Competencia objetiva y territorial** (arts. 50-52 LEC). Reglas frecuentes: domicilio del demandado (regla general); inmuebles → lugar del inmueble; consumidores → domicilio del consumidor; arrendamientos → lugar del inmueble; sucesiones → último domicilio del causante; seguros → domicilio del asegurado.

3. **MASC** — comprobar si el caso entra en las excepciones tasadas del art. 5.3 LO 1/2025 (ver `references/excepciones.md`). Si no entra, exigir al cliente la prueba documental del intento de negociación previa.

4. **Plazos críticos**: caducidad, prescripción, plazos del MASC (30 días sin respuesta = cumplido), enervación en desahucio, plazo de impugnación de acuerdos en propiedad horizontal (1 año), etc.

5. **Devolver a Carlos un dictamen interno breve** con: procedimiento que toca, tribunal competente, MASC aplicable o no, plazos críticos detectados, y luces verdes/rojas para seguir.

### FASE 3 — Estrategia procesal

Lectura obligatoria de `references/fase-3-estrategia.md`. Antes de redactar:

1. **Definir con Carlos la pretensión exacta** que va al suplico: cuantía líquida, intereses (legales / mora / pactados), costas, condena por temeridad (art. 394.2 LEC) si procede, pretensiones subsidiarias.
2. **Estrategia probatoria**: qué documentos van como anexos numerados, qué interrogatorios se propondrán, qué peritos se aportarán, qué testigos.
3. **Otrosíes que conviene incluir**: cuantía y procedimiento, prueba (anuncio expreso art. 265.1 LEC), medidas cautelares (si procede), justicia gratuita, copias para traslado, dirección electrónica para notificaciones.
4. **Cláusula de cierre estratégico**: si hay riesgo de inadmisión por defecto procesal, anticiparlo en otrosí.
5. **Confirmar con Carlos** la línea estratégica antes de redactar. Si Carlos discrepa, anotar su decisión y seguir su criterio, dejando registrada la opinión letrada.

### FASE 4 — Jurisprudencia: 5 STS verificadas (vía vLex)

Lectura obligatoria de `references/fase-4-jurisprudencia.md`. Reglas:

1. **Mínimo 5 STS** aplicables al caso, con **ECLI verificado en vLex** (preferente) o CENDOJ. Para cada una:
   - ECLI completo.
   - Sala (1ª de lo Civil normalmente) y ponente.
   - Fecha y nº de recurso.
   - Ratio decidendi en una o dos frases.
   - Cita literal corta (15-35 palabras) entre comillas — directamente del texto.
   - Aplicación al caso: cómo se proyecta sobre los hechos concretos del cliente.

2. **Verificación obligatoria** invocando internamente la skill `vlex-jurisprudencia` (preferente). Si Carlos lo prefiere, `cendoj-jurisprudencia`. Si una STS no se localiza, no se cita.

3. **Sentencias de la AP competente**: opcionales, solo si Carlos lo pide o si la doctrina del TS no es unánime y conviene mostrar la línea de la AP.

4. **Distribución por fundamento**: cada Fundamento de Derecho sustantivo debe sostenerse en al menos **una STS principal y una de refuerzo**. Si solo hay una, decírselo a Carlos.

5. **Anti-cita suelta**: ninguna sentencia se cita sin un párrafo posterior que la **subsuma** en los hechos del caso. Para esto, al final, se invocará la skill `subsuncion-juridica-skill`.

### FASE 5 — Redacción extensa y entrega Word maquetado

Lectura obligatoria de `references/fase-5-redaccion-word.md` y `references/plantilla-word-formato.md`.

**Estructura del escrito** (en este orden, sin saltarse ninguna sección):

1. Encabezamiento: `AL TRIBUNAL DE INSTANCIA DE [LOCALIDAD] — SECCIÓN [CIVIL/FAMILIA/MERCANTIL]`.
2. Comparecencia: procurador (con poder, si preceptivo) y letrado (nombre, colegiado, despacho, dirección electrónica).
3. Identificación del actor y del demandado (nombre/razón social, NIF/CIF, domicilio, representación).
4. Fórmula procesal: *"Mediante el presente escrito INTERPONGO DEMANDA DE [tipo de juicio] frente a [demandado], en virtud de los siguientes…"*.
5. **HECHOS** numerados correlativamente (PRIMERO, SEGUNDO, TERCERO…). Incluir obligatoriamente un HECHO específico sobre el cumplimiento del MASC (art. 399.3 LEC) salvo excepción.
6. **FUNDAMENTOS DE DERECHO** numerados, separando:
   - I. Competencia objetiva y territorial.
   - II. Legitimación activa y pasiva.
   - III. Procedimiento aplicable.
   - IV. Postulación procesal.
   - V. Cumplimiento del MASC (art. 5 LO 1/2025) o excepción aplicable.
   - VI. Fondo del asunto (subsunción real con la jurisprudencia STS).
   - VII. Costas (art. 394 LEC) e intereses.
7. **SUPLICO**: peticiones claras, numeradas, líquidas (o liquidables), con condena en costas y, si procede, intereses legales o de demora.
8. **OTROSÍES** numerados (cuantía, prueba que se propondrá, medidas cautelares, justicia gratuita, copias, dirección electrónica…).
9. Lugar, fecha, firmas (letrado y procurador) y enumeración de documentos acompañados.

**Extensión deseada**: la demanda es desarrollada y exhaustiva. Como referencia, no menos de 8 páginas para un asunto medio; en monitorios sencillos puede bajar a 4-6 páginas. La extensión por sí sola no es virtud, pero la subsunción detallada sí.

**Formato Word obligatorio** (resumen — detalle en `references/plantilla-word-formato.md`):
- Times New Roman 12 pt, interlineado 1,15.
- Márgenes: 3 cm izquierdo, 2,5 cm resto.
- Títulos centrados en negrita y mayúsculas.
- Numeración ordinal escrita: PRIMERO, SEGUNDO, TERCERO…
- Negritas estratégicas en partes, artículos, ECLI, fechas, cantidades.
- Pie de firma a dos columnas (letrado izquierda, procurador derecha) cuando proceda.
- Documentos acompañados enumerados al final.

Para generar el `.docx` usar el script `scripts/generar_demanda_word.py` (preferente — aplica todo el formato automáticamente con python-docx) o, en su defecto, la skill `docx`. **Nunca entregar texto plano ni Markdown como producto final.**

**Última pasada — estilo Carlos**: invocar `estilo-carlos-escritos-judiciales` para imprimir la pluma de Carlos. **Sin esta pasada el escrito no se entrega.**

**Verificación final ECLI**: invocar `verificacion-ecli-skill` para auditar que cada cita jurisprudencial existe realmente. Si alguna falla, eliminarla y rehacer el bloque correspondiente antes de entregar.

---

## Subskills que esta skill encadena

Cuando convenga, esta skill llama internamente a otras skills del ecosistema de Carlos:

| Subskill | Cuándo se invoca | Para qué |
| --- | --- | --- |
| `vlex-jurisprudencia` | Fase 4 (preferente) | Búsqueda y verificación de las 5 STS con ECLI. |
| `cendoj-jurisprudencia` | Fase 4 (alternativa) | Si Carlos prefiere CENDOJ o si vLex falla. |
| `analisis-sentencias-skill` | Fase 4 (apoyo) | Ficha rápida de una sentencia clave aportada al expediente. |
| `subsuncion-juridica-skill` | Fase 5 (pulido) | Conectar cada cita jurisprudencial con los hechos del caso. |
| `verificacion-ecli-skill` | Fase 5 (control) | Auditoría final de los ECLI antes de entregar. |
| `estilo-carlos-escritos-judiciales` | Fase 5 (estilo) | Capa final de pluma para que el escrito suene a Carlos. |
| `formato-escritos-judiciales` | Fase 5 (formato) | Refuerza el formato visual y la entrega Word. |
| `docx` | Fase 5 (Word) | Maquetar y generar el `.docx` final si no se usa el script propio. |
| `lo-1-2025-resumen` | Fases 0-2 (referencia) | Cuando haya duda sobre régimen transitorio o terminología. |
| `costas-procesales` | Fase 3 (estrategia) | Si la pretensión incluye condena en costas por temeridad. |
| `medidas-cautelares` | Fase 3 (estrategia) | Si el caso requiere medida cautelar previa o coetánea. |

---

## Reglas de calidad y estilo

- Estilo de casación: técnico, contundente, sin adjetivos huecos. Cero "claramente", "evidentemente", "manifiestamente"; solo si están realmente ganados por los hechos.
- Cada afirmación de hecho referida al expediente debe citar el documento o folio (ej.: *"según se acredita en el documento nº 4"*).
- Cada cita jurisprudencial lleva ECLI y comillas en la cita literal.
- Cada Fundamento de Derecho sustantivo termina con una **subsunción** explícita: "*Aplicada esta doctrina al supuesto de autos…*".
- Distinguir siempre entre hechos (qué pasó), prueba (cómo se acredita) y derecho (por qué procede).
- Anti-muletilla: rotar verbos (señala, indica, declara, sostiene, razona, concluye, recuerda, advierte, precisa, matiza). Evitar repeticiones.
- En el suplico, peticiones **numeradas** y **cuantificadas**, no abstractas.
- Otrosíes con denominación procesal correcta (Otrosí Primero Digo, Otrosí Segundo Digo…) y suplico autónomo en cada uno.

---

## Reglas anti-error

- Si una STS no se localiza en vLex/CENDOJ tras dos intentos razonables → eliminarla y avisar a Carlos.
- Si la doctrina del TS sobre la materia está dividida → exponer ambas líneas y razonar por qué la nuestra es preferente.
- Si el caso encaja en una excepción del MASC → justificarla expresamente con cita del art. 5.3 LO 1/2025; no omitir el HECHO sin más.
- Si Carlos no contesta a una batería en la sesión → guardar el contexto, no inventar lo que no se sabe.
- Si Carlos pide saltarse la verificación ECLI → recordarle el riesgo, dejar nota expresa en el chat y, solo si insiste, marcar las STS como `[NO VERIFICADAS]` en el borrador.
- Si la cuantía es indeterminada → razonar en otrosí cómo se determina (art. 253 LEC) y, en su defecto, seguir el procedimiento ordinario.
- Si el demandado tiene domicilio desconocido → declaración responsable del art. 264.4 LEC (modelo en `references/modelos-masc.md`).
- Si la entrega final no es un `.docx` maquetado → no se entrega. Se vuelve a la Fase 5 y se genera el Word.

---

## Recursos del paquete

| Archivo | Para qué sirve |
| --- | --- |
| `assets/plantilla-demanda.docx` | Plantilla Word base (a respetar márgenes, tipografía y pie de firma). |
| `references/procedimientos.md` | Cuadro completo por tipo de procedimiento (ordinario, verbal, monitorio, desahucio, ejecución, familia, cambiario). |
| `references/modelos-masc.md` | Modelos de burofax, comunicación entre letrados, acta de negociación fallida, declaración responsable, oferta vinculante. |
| `references/excepciones.md` | Excepciones al MASC y casos especiales (consumidores, circulación, propiedad horizontal, transfronterizos). |
| `references/fase-0-recopilacion-documentos.md` | Checklist documental por tipo de demanda. |
| `references/fase-1-bateria-preguntas.md` | Baterías estructuradas para `AskUserQuestion`. |
| `references/fase-2-viabilidad-procedimiento.md` | Análisis de viabilidad, competencia, plazos. |
| `references/fase-3-estrategia.md` | Estrategia procesal, prueba, otrosíes, suplico. |
| `references/fase-4-jurisprudencia.md` | Cómo invocar vLex/CENDOJ, qué pedir y cómo formatear las citas. |
| `references/fase-5-redaccion-word.md` | Estructura completa del escrito y reglas de redacción. |
| `references/plantilla-word-formato.md` | Especificaciones de formato Word (Times 12, márgenes, encabezamiento). |
| `references/checklist-pre-presentacion.md` | Checklist final antes de entregar. |
| `scripts/generar_demanda_word.py` | Script python-docx para generar la demanda final con formato. |

---

## Checklist final antes de entregar

Lectura obligatoria de `references/checklist-pre-presentacion.md`. Repasar uno a uno todos los puntos antes de generar el `.docx`. Si alguno falla, no se entrega.

Resumen de lo imprescindible:

- [ ] Dirigida al **Tribunal de Instancia** competente con la sección correcta (no "Juzgado").
- [ ] HECHO específico de cumplimiento del MASC + Documento del art. 264.4 LEC (o excepción justificada).
- [ ] Art. 399.3 LEC: descripción de la negociación previa.
- [ ] Mínimo 5 STS con ECLI verificado en vLex/CENDOJ.
- [ ] Cada FD sustantivo cierra con subsunción a los hechos.
- [ ] Suplico líquido, numerado, con costas e intereses.
- [ ] Otrosíes con denominación procesal correcta y suplico autónomo.
- [ ] Pasada de `estilo-carlos-escritos-judiciales` aplicada.
- [ ] Pasada de `verificacion-ecli-skill` aplicada y todas las citas confirmadas.
- [ ] Entregado en `.docx` maquetado (Times 12, márgenes, pie de firma).
- [ ] Documentos numerados y enumerados en el cierre del escrito.

---

## Disclaimers

- Esta skill es una herramienta de apoyo profesional. La responsabilidad sobre la demanda final firmada y presentada es siempre del letrado interviniente (Carlos).
- La normativa procesal varía y la LO 1/2025 está en aplicación escalonada; cuando haya duda, consultar la última versión consolidada de la LEC en el BOE o invocar la skill `lo-1-2025-resumen`.
